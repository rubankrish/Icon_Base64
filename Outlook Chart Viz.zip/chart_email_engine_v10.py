"""
╔══════════════════════════════════════════════════════════════════════╗
║      BigQuery Chart Engine  —  v10  (Final · Production Ready)      ║
╠══════════════════════════════════════════════════════════════════════╣
║                                                                      ║
║  AUTH    : Service Account JSON key file                             ║
║                                                                      ║
║  READS   : email_body    — html with {{PLACEHOLDERS}}                ║
║            chart_config  — one row per chart placeholder             ║
║                                                                      ║
║  WRITES  : email_output  — rendered HTML pushed back to BigQuery     ║
║                                                                      ║
║  CHART TYPES (v7):                                                   ║
║    line        — smooth multi-series line with gradient fill         ║
║    bar         — grouped bars with rounded tops + value labels       ║
║    pie         — pie with outer callout labels                       ║
║    donut       — donut with animated centre KPI label                ║
║    area        — stacked area chart                                  ║
║    hbar        — horizontal bar with inline labels                   ║
║    scatter     — NEW: scatter / bubble plot (optional size col)      ║
║    combo       — NEW: bar + line overlay (dual-axis)                 ║
║    waterfall   — NEW: running-total waterfall / bridge chart         ║
║                                                                      ║
║  DESIGN IMPROVEMENTS (v7):                                           ║
║    • Dark-mode-aware palette: each theme ships a dark variant        ║
║    • Legend band now uses pill-shaped colour chips (not circles)     ║
║    • Axis labels supported (x_label / y_label config columns)        ║
║    • Subtitle row under chart title (subtitle config column)         ║
║    • Reference line support — ref_line_value + ref_line_label        ║
║    • Threshold band: fill between min/max reference range            ║
║    • Zero-baseline rule drawn as thin solid line (not grid)          ║
║    • Smart tick count: auto-reduce to ≤8 ticks on dense x-axes       ║
║    • Long category labels auto-rotated & wrapped at 12 chars         ║
║    • Pie/donut: adaptive callout radius prevents label collision      ║
║    • Bar: gradient fill per bar (top bright → bottom muted)          ║
║    • hbar: progress-track background with % completion feel          ║
║    • Waterfall: positive=green, negative=red, total=primary          ║
║    • Combo: secondary y-axis auto-scaled independently               ║
║    • Scatter: colour-coded by optional category column               ║
║    • 260 DPI export (up from 240)                                    ║
║    • Timestamp + email_id watermark baked into footer strip          ║
║    • _envelope: responsive 2-column stat banner above charts         ║
║    • process_emails: parallel chart rendering via ThreadPoolExecutor ║
║    • build_output_row: richer status — WARN level for partial        ║
║    • All renderers accept dark_mode=True flag from config            ║
║                                                                      ║
╚══════════════════════════════════════════════════════════════════════╝
"""

import io, os, re, json, base64, textwrap, warnings
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Optional

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import matplotlib.patches as mpatches
import matplotlib.patheffects as pe
from matplotlib.patches import FancyBboxPatch
from matplotlib.colors import LinearSegmentedColormap, to_rgba


# ══════════════════════════════════════════════════════════════════════
# ▶  CONFIG
# ══════════════════════════════════════════════════════════════════════

SERVICE_ACCOUNT_KEY_FILE = "service_account_key.json"
PROJECT_ID               = "your-gcp-project-id"
EMAIL_BODY_VIEW          = "your_project.your_dataset.email_body"
CHART_CONFIG_TABLE       = "your_project.your_dataset.chart_config"
EMAIL_OUTPUT_TABLE       = "your_project.your_dataset.email_output"
WRITE_MODE               = "APPEND"      # APPEND | TRUNCATE
OUTPUT_DIR               = "output_emails"
USE_MOCK                 = True
MAX_WORKERS              = 4             # parallel chart rendering threads

# ══════════════════════════════════════════════════════════════════════
# ▶  TABLE VARIABLE SUBSTITUTION
# ══════════════════════════════════════════════════════════════════════
#
#  Any value in chart_config (bq_table, filters, x_column, y_columns,
#  title, subtitle …) can contain {variable} placeholders that are
#  resolved at runtime from TABLE_VARS below.
#
#  Built-in auto-variables (always available, no need to define here):
#    {project}        → PROJECT_ID
#    {today}          → YYYY-MM-DD  (UTC)
#    {yesterday}      → YYYY-MM-DD  (UTC)
#    {this_month}     → YYYY-MM    (e.g. 2026-04)
#    {last_month}     → YYYY-MM    (e.g. 2026-03)
#    {this_year}      → YYYY        (e.g. 2026)
#    {last_year}      → YYYY        (e.g. 2025)
#    {this_quarter}   → Q1 / Q2 / Q3 / Q4
#    {last_quarter}   → Q1 / Q2 / Q3 / Q4
#    {this_quarter_year} → e.g. Q1-2026
#    {last_quarter_year} → e.g. Q4-2025
#    {env}            → value of TABLE_VARS["env"]  (default "prod")
#
#  Examples:
#    bq_table  = "{project}.{env}_analytics.monthly_sales"
#    filters   = "report_date = '{today}'"
#    filters   = "period = '{this_quarter_year}'"
#    title     = "Revenue — {this_month}"
#
#  Add any custom key→value pairs you need:

TABLE_VARS: dict = {
    # "env":       "prod",          # overrides the default "prod"
    # "region":    "APAC",
    # "dataset":   "sales_v2",
    # "run_date":  "2026-04-01",    # pin a specific date
}



# ══════════════════════════════════════════════════════════════════════
# 0.  TABLE VARIABLE RESOLVER
# ══════════════════════════════════════════════════════════════════════

def _quarter(month: int) -> str:
    return f"Q{(month - 1) // 3 + 1}"

def _prev_quarter(year: int, month: int) -> tuple:
    """Return (year, quarter_str) for the quarter before the given month."""
    q = (month - 1) // 3 + 1
    if q == 1:
        return year - 1, "Q4"
    return year, f"Q{q - 1}"

def _build_runtime_vars() -> dict:
    """
    Build the full variable dict available for substitution.
    Merges auto-computed date/env vars with user-defined TABLE_VARS.
    User TABLE_VARS always win on collision (except protected built-ins).
    """
    now        = datetime.now(timezone.utc)
    y, m       = now.year, now.month
    today_str  = now.strftime("%Y-%m-%d")

    # yesterday
    from datetime import timedelta
    yesterday  = (now - timedelta(days=1)).strftime("%Y-%m-%d")

    # last month
    lm_year, lm_month = (y - 1, 12) if m == 1 else (y, m - 1)

    # quarters
    tq         = _quarter(m)
    lq_year, lq = _prev_quarter(y, m)

    auto: dict = {
        "project":            PROJECT_ID,
        "today":              today_str,
        "yesterday":          yesterday,
        "this_month":         now.strftime("%Y-%m"),
        "last_month":         f"{lm_year}-{lm_month:02d}",
        "this_year":          str(y),
        "last_year":          str(y - 1),
        "this_quarter":       tq,
        "last_quarter":       lq,
        "this_quarter_year":  f"{tq}-{y}",
        "last_quarter_year":  f"{lq}-{lq_year}",
        "env":                "prod",          # default; override via TABLE_VARS
    }
    # User vars override auto vars (except "project" which stays authoritative)
    merged = {**auto, **TABLE_VARS}
    merged["project"] = PROJECT_ID           # project always reflects top-level config
    return merged


def resolve(text: str, runtime_vars: dict | None = None) -> str:
    """
    Replace every {key} in *text* with the matching runtime variable.

    Rules:
      • Unknown keys are left unchanged (won't crash the pipeline).
      • Nested resolution: resolved values are themselves resolved once more
        (allows chaining like {env} inside a value that uses {dataset}).
      • Case-insensitive key lookup for convenience.

    Examples:
      resolve("{project}.{env}_analytics.monthly_sales")
      → "your-gcp-project-id.prod_analytics.monthly_sales"

      resolve("report_date = '{today}'")
      → "report_date = '2026-04-24'"

      resolve("period = '{last_quarter_year}'")
      → "period = 'Q1-2026'"
    """
    if not text or "{" not in text:
        return text

    if runtime_vars is None:
        runtime_vars = _build_runtime_vars()

    # Build case-insensitive lookup
    lower_map = {k.lower(): v for k, v in runtime_vars.items()}

    def _replacer(match: re.Match) -> str:
        key = match.group(1).strip()
        # Try exact, then lowercase
        val = runtime_vars.get(key, lower_map.get(key.lower()))
        if val is None:
            return match.group(0)          # leave unknown vars untouched
        # One level of nested resolution
        return resolve(str(val), runtime_vars)

    return re.sub(r"\{([^}]+)\}", _replacer, text)


def resolve_cfg(cfg: dict, runtime_vars: dict | None = None) -> dict:
    """
    Apply variable substitution to all string fields of a parsed config dict.
    Returns a new dict (original is not mutated).
    """
    if runtime_vars is None:
        runtime_vars = _build_runtime_vars()

    STRING_FIELDS = (
        "bq_table", "filters", "x_column", "title", "subtitle",
        "ref_line_value", "ref_line_label", "x_label", "y_label",
    )
    out = dict(cfg)
    for field in STRING_FIELDS:
        if field in out and isinstance(out[field], str):
            out[field] = resolve(out[field], runtime_vars)
    # y_columns is a list of strings
    out["y_columns"] = [resolve(c, runtime_vars) for c in cfg.get("y_columns", [])]
    return out


# ══════════════════════════════════════════════════════════════════════
# 1.  BIGQUERY CLIENT
# ══════════════════════════════════════════════════════════════════════

class BigQueryClient:
    """
    Service Account auth. Handles READ (query) and WRITE (insert).

    IAM roles needed:
      - roles/bigquery.dataViewer
      - roles/bigquery.dataEditor   (for email_output writes)
      - roles/bigquery.jobUser
    """

    def __init__(self):
        self.client = None
        if USE_MOCK:
            print("  [MODE] Mock — skipping BigQuery connection.")
            return
        key_path = SERVICE_ACCOUNT_KEY_FILE
        if not os.path.isfile(key_path):
            raise FileNotFoundError(
                f"Key not found: '{key_path}'\n"
                "GCP Console → IAM & Admin → Service Accounts → Keys → Add Key → JSON."
            )
        from google.oauth2 import service_account
        from google.cloud import bigquery
        creds = service_account.Credentials.from_service_account_file(
            key_path, scopes=["https://www.googleapis.com/auth/bigquery"]
        )
        self.client = bigquery.Client(project=PROJECT_ID, credentials=creds)
        with open(key_path) as f:
            m = json.load(f)
        print(f"  [AUTH] {m.get('client_email','?')}  /  {m.get('project_id','?')}")

    def query(self, sql: str) -> pd.DataFrame:
        if USE_MOCK:
            return _mock(sql)
        return self.client.query(sql).to_dataframe()

    def insert_rows(self, table_id: str, rows: list, write_mode: str = "APPEND"):
        if USE_MOCK:
            print(f"  [MOCK WRITE] {len(rows)} row(s) → {table_id}  ({write_mode})")
            for r in rows:
                p = {k: (str(v)[:70]+"…" if isinstance(v, str) and len(str(v))>70 else v)
                     for k, v in r.items()}
                print(f"    {p}")
            return
        from google.cloud import bigquery
        schema = [
            bigquery.SchemaField("email_id",       "STRING"),
            bigquery.SchemaField("sender_email",    "STRING"),
            bigquery.SchemaField("recipient_email", "STRING"),
            bigquery.SchemaField("subject",         "STRING"),
            bigquery.SchemaField("final_html",      "STRING"),
            bigquery.SchemaField("charts_injected", "INTEGER"),
            bigquery.SchemaField("status",          "STRING"),
            bigquery.SchemaField("error_message",   "STRING"),
            bigquery.SchemaField("processed_at",    "TIMESTAMP"),
        ]
        disp = {
            "APPEND":   bigquery.WriteDisposition.WRITE_APPEND,
            "TRUNCATE": bigquery.WriteDisposition.WRITE_TRUNCATE,
        }.get(write_mode.upper(), bigquery.WriteDisposition.WRITE_APPEND)
        cfg = bigquery.LoadJobConfig(schema=schema, write_disposition=disp)
        job = self.client.load_table_from_dataframe(
            pd.DataFrame(rows), table_id, job_config=cfg
        )
        job.result()
        print(f"  [BQ WRITE] {len(rows)} row(s) → {table_id}  ({write_mode})")


# ══════════════════════════════════════════════════════════════════════
# 2.  MOCK DATA
# ══════════════════════════════════════════════════════════════════════

def _mock(sql: str) -> pd.DataFrame:
    u = sql.upper()

    # ══════════════════════════════════════════════════════════════════
    #  EMAIL BODY — 3 reports
    # ══════════════════════════════════════════════════════════════════
    if "EMAIL_BODY" in u:
        def _sec(label):
            return (
                f"<div style='font-size:10px;font-weight:700;color:#9AA3B8;"
                f"letter-spacing:0.10em;text-transform:uppercase;padding-bottom:8px;"
                f"margin-bottom:12px;border-bottom:1px solid #EEF1F6;"
                f"font-family:Arial;'>{label}</div>"
            )
        return pd.DataFrame([
            # ── R001: Monthly Sales Performance ───────────────────────
            {
                "email_id":        "R001",
                "sender_email":    "reports@company.com",
                "subject":         "Monthly Sales Performance — {this_month}",
                "recipient_email": "sales-team@company.com",
                "html_body": (
                    "<p style='font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 20px;'>Dear Sales Team,</p>"
                    "<p style='font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 28px;'>Here is your monthly sales performance summary with revenue trends, regional breakdown, and deal pipeline analysis.</p>"
                    + _sec("Revenue Trend vs Target") + "{{R001_LINE_REVENUE}}"
                    + _sec("Revenue by Region") + "{{R001_PIE_REGION}}"
                    + _sec("Top Regions Ranked") + "{{R001_HBAR_REGION}}"
                    + _sec("Deal Size vs Revenue") + "{{R001_SCATTER_DEALS}}"
                    + _sec("Revenue & Units Combo") + "{{R001_COMBO_UNITS}}"
                    + "<p style='font-family:Arial;font-size:13px;color:#6B7280;margin:28px 0 0;line-height:1.7;'>Best regards,<br/><strong style='color:#111827;'>Analytics Team</strong></p>"
                ),
            },
            # ── R002: Product & Category Analytics ────────────────────
            {
                "email_id":        "R002",
                "sender_email":    "reports@company.com",
                "subject":         "Product & Category Analytics — {this_quarter_year}",
                "recipient_email": "product-team@company.com",
                "html_body": (
                    "<p style='font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 20px;'>Dear Product Team,</p>"
                    "<p style='font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 28px;'>Here is the quarterly product and category performance breakdown including market share and segment analysis.</p>"
                    + _sec("Quarterly Sales by Category") + "{{R002_BAR_CATEGORY}}"
                    + _sec("Market Share — Sunburst") + "{{R002_SUNBURST_MARKET}}"
                    + _sec("Market Share by Segment") + "{{R002_DONUT_MARKET}}"
                    + _sec("Category Growth Area") + "{{R002_AREA_GROWTH}}"
                    + "<p style='font-family:Arial;font-size:13px;color:#6B7280;margin:28px 0 0;line-height:1.7;'>Best regards,<br/><strong style='color:#111827;'>Analytics Team</strong></p>"
                ),
            },
            # ── R003: Executive P&L Summary ───────────────────────────
            {
                "email_id":        "R003",
                "sender_email":    "reports@company.com",
                "subject":         "Executive P&L Summary — {last_quarter_year}",
                "recipient_email": "leadership@company.com",
                "html_body": (
                    "<p style='font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 20px;'>Dear Leadership Team,</p>"
                    "<p style='font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 28px;'>Please find the executive P&amp;L summary for {last_quarter_year} including cost structure, revenue bridge, and expense sunburst.</p>"
                    + _sec("P&L Bridge — {last_quarter_year}") + "{{R003_WATERFALL_PNL}}"
                    + _sec("Cost Structure Sunburst") + "{{R003_SUNBURST_COST}}"
                    + _sec("Revenue vs Costs — Monthly") + "{{R003_LINE_REVCOS}}"
                    + _sec("Expense Breakdown") + "{{R003_PIE_EXPENSE}}"
                    + "<p style='font-family:Arial;font-size:13px;color:#6B7280;margin:28px 0 0;line-height:1.7;'>Best regards,<br/><strong style='color:#111827;'>Analytics Team</strong></p>"
                ),
            },
        ])

    # ══════════════════════════════════════════════════════════════════
    #  CHART CONFIG — all charts for all 3 reports
    # ══════════════════════════════════════════════════════════════════
    if "CHART_CONFIG" in u:
        return pd.DataFrame([
            # ── R001 charts ───────────────────────────────────────────
            {"variable_name":"R001_LINE_REVENUE","chart_type":"line",
             "bq_table":"{project}.{env}_reports.monthly_sales","filters":"report_year={this_year}",
             "x_column":"Month","y_columns":"Revenue,Target","legend":"yes",
             "title":"Monthly Revenue vs Target","subtitle":"Jan–Dec {this_year}",
             "color_theme":"blue","show_values":"no","sort_order":"none",
             "width_px":620,"height_px":310,
             "ref_line_value":"70000","ref_line_label":"Monthly Target",
             "x_label":"","y_label":"Revenue (USD)","dark_mode":"no"},

            {"variable_name":"R001_PIE_REGION","chart_type":"pie",
             "bq_table":"{project}.{env}_reports.region_revenue","filters":"report_year={this_year}",
             "x_column":"Region","y_columns":"Revenue","legend":"yes",
             "title":"Revenue by Region","subtitle":"FY {this_year}",
             "color_theme":"vibrant","show_values":"yes","sort_order":"desc",
             "width_px":520,"height_px":360,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"","y_label":"","dark_mode":"no"},

            {"variable_name":"R001_HBAR_REGION","chart_type":"hbar",
             "bq_table":"{project}.{env}_reports.region_revenue","filters":"report_year={this_year}",
             "x_column":"Region","y_columns":"Revenue","legend":"no",
             "title":"Revenue Ranking by Region","subtitle":"Sorted high to low",
             "color_theme":"teal","show_values":"yes","sort_order":"desc",
             "width_px":560,"height_px":290,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"Revenue (USD)","y_label":"","dark_mode":"no"},

            {"variable_name":"R001_SCATTER_DEALS","chart_type":"scatter",
             "bq_table":"{project}.{env}_reports.deal_performance","filters":"report_year={this_year}",
             "x_column":"DealSize","y_columns":"Revenue,Count,Segment","legend":"yes",
             "title":"Deal Size vs Revenue","subtitle":"Bubble = deal count · {this_quarter_year}",
             "color_theme":"purple","show_values":"no","sort_order":"none",
             "width_px":560,"height_px":310,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"Deal Size (USD)","y_label":"Revenue (USD)","dark_mode":"no"},

            {"variable_name":"R001_COMBO_UNITS","chart_type":"combo",
             "bq_table":"{project}.{env}_reports.monthly_sales","filters":"report_year={this_year}",
             "x_column":"Month","y_columns":"Revenue,Units","legend":"yes",
             "title":"Revenue vs Units Sold","subtitle":"Bars = Revenue  /  Line = Units",
             "color_theme":"blue","show_values":"no","sort_order":"none",
             "width_px":620,"height_px":320,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"","y_label":"Revenue (USD)","dark_mode":"no"},

            # ── R002 charts ───────────────────────────────────────────
            {"variable_name":"R002_BAR_CATEGORY","chart_type":"bar",
             "bq_table":"{project}.{env}_reports.category_quarterly","filters":"fiscal_year={this_year}",
             "x_column":"Category","y_columns":"Q1,Q2,Q3,Q4","legend":"yes",
             "title":"Quarterly Sales by Category","subtitle":"FY {this_year} breakdown",
             "color_theme":"cool","show_values":"yes","sort_order":"none",
             "width_px":620,"height_px":330,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"","y_label":"Sales (USD)","dark_mode":"no"},

            {"variable_name":"R002_SUNBURST_MARKET","chart_type":"sunburst",
             "bq_table":"{project}.{env}_reports.market_sunburst","filters":"report_year={this_year}",
             "x_column":"Segment","y_columns":"Revenue,SubSegment","legend":"yes",
             "title":"Revenue by Segment & Sub-Segment","subtitle":"Two-level breakdown · FY {this_year}",
             "color_theme":"vibrant","show_values":"yes","sort_order":"desc",
             "width_px":560,"height_px":400,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"","y_label":"","dark_mode":"no"},

            {"variable_name":"R002_DONUT_MARKET","chart_type":"donut",
             "bq_table":"{project}.{env}_reports.market_share","filters":"report_year={this_year}",
             "x_column":"Segment","y_columns":"Share","legend":"yes",
             "title":"Market Share by Segment","subtitle":"As of {this_month}",
             "color_theme":"warm","show_values":"yes","sort_order":"desc",
             "width_px":500,"height_px":360,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"","y_label":"","dark_mode":"no"},

            {"variable_name":"R002_AREA_GROWTH","chart_type":"area",
             "bq_table":"{project}.{env}_reports.monthly_sales","filters":"report_year={this_year}",
             "x_column":"Month","y_columns":"Revenue,Target","legend":"yes",
             "title":"Cumulative Growth — Revenue vs Target","subtitle":"YTD · {this_month}",
             "color_theme":"blue","show_values":"no","sort_order":"none",
             "width_px":620,"height_px":310,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"","y_label":"USD","dark_mode":"no"},

            # ── R003 charts ───────────────────────────────────────────
            {"variable_name":"R003_WATERFALL_PNL","chart_type":"waterfall",
             "bq_table":"{project}.{env}_reports.pnl_bridge","filters":"period='{last_quarter_year}'",
             "x_column":"Item","y_columns":"Delta","legend":"no",
             "title":"P&L Bridge — {last_quarter_year}","subtitle":"Starting from Opening Balance",
             "color_theme":"default","show_values":"yes","sort_order":"none",
             "width_px":620,"height_px":330,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"","y_label":"USD","dark_mode":"no"},

            {"variable_name":"R003_SUNBURST_COST","chart_type":"sunburst",
             "bq_table":"{project}.{env}_reports.cost_sunburst","filters":"period='{last_quarter_year}'",
             "x_column":"CostCategory","y_columns":"Amount,CostItem","legend":"yes",
             "title":"Cost Structure Breakdown","subtitle":"Inner = Category  ·  Outer = Line Item",
             "color_theme":"warm","show_values":"yes","sort_order":"desc",
             "width_px":560,"height_px":400,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"","y_label":"","dark_mode":"no"},

            {"variable_name":"R003_LINE_REVCOS","chart_type":"line",
             "bq_table":"{project}.{env}_reports.monthly_pnl","filters":"report_year={this_year}",
             "x_column":"Month","y_columns":"Revenue,Costs,GrossProfit","legend":"yes",
             "title":"Revenue vs Costs — Monthly","subtitle":"Gross profit = Revenue − Costs",
             "color_theme":"green","show_values":"no","sort_order":"none",
             "width_px":620,"height_px":310,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"","y_label":"USD","dark_mode":"no"},

            {"variable_name":"R003_PIE_EXPENSE","chart_type":"pie",
             "bq_table":"{project}.{env}_reports.expense_breakdown","filters":"period='{last_quarter_year}'",
             "x_column":"ExpenseType","y_columns":"Amount","legend":"yes",
             "title":"Expense Breakdown","subtitle":"{last_quarter_year}",
             "color_theme":"slate","show_values":"yes","sort_order":"desc",
             "width_px":520,"height_px":360,
             "ref_line_value":"","ref_line_label":"",
             "x_label":"","y_label":"","dark_mode":"no"},
        ])

    # ══════════════════════════════════════════════════════════════════
    #  DATA TABLES
    # ══════════════════════════════════════════════════════════════════
    if "MONTHLY_SALES" in u or "MONTHLY_PNL" in u:
        base = pd.DataFrame({
            "Month":   ["Jan","Feb","Mar","Apr","May","Jun",
                        "Jul","Aug","Sep","Oct","Nov","Dec"],
            "Revenue": [42000,47500,53200,49800,61000,67300,
                        72100,68900,74500,81200,78600,91000],
            "Target":  [45000,48000,52000,55000,60000,65000,
                        70000,72000,75000,80000,82000,88000],
            "Units":   [210,238,266,249,305,337,
                        361,345,373,406,393,455],
        })
        if "MONTHLY_PNL" in u:
            base["Costs"]       = [31000,34000,38000,37000,43000,48000,
                                   51000,49000,53000,57000,55000,63000]
            base["GrossProfit"] = (base["Revenue"] - base["Costs"]).tolist()
        return base

    if "REGION_REVENUE" in u:
        return pd.DataFrame({
            "Region":  ["North","South","East","West","Central"],
            "Revenue": [31200,24500,18900,27800,15600],
        })

    if "CATEGORY_QUARTERLY" in u:
        return pd.DataFrame({
            "Category": ["Electronics","Clothing","Food","Books","Sports"],
            "Q1":[12000,8500,6200,3400,5100],
            "Q2":[14500,9200,7800,4100,6300],
            "Q3":[13200,11000,8100,3800,7200],
            "Q4":[18900,14500,9300,4600,8800],
        })

    if "MARKET_SHARE" in u:
        return pd.DataFrame({
            "Segment": ["Enterprise","SMB","Startup","Consumer","Government"],
            "Share":   [38.5,24.2,15.8,12.1,9.4],
        })

    if "MARKET_SUNBURST" in u:
        return pd.DataFrame({
            "Segment":    ["Enterprise","Enterprise","Enterprise",
                           "SMB","SMB",
                           "Startup","Startup",
                           "Consumer","Consumer","Consumer",
                           "Government","Government"],
            "SubSegment": ["Large Corp","Mid Corp","Public Co",
                           "Retail SMB","B2B SMB",
                           "SaaS","Fintech",
                           "Direct","Reseller","Online",
                           "Federal","State"],
            "Revenue":    [18000,9500,6200,
                           14000,9800,
                           8200,7100,
                           6500,4100,2800,
                           5200,3800],
        })

    if "DEAL_PERFORMANCE" in u:
        rng = np.random.default_rng(42)
        n   = 40
        return pd.DataFrame({
            "DealSize": rng.integers(5000,  120000, n).tolist(),
            "Revenue":  rng.integers(3000,   95000, n).tolist(),
            "Count":    rng.integers(1,          15, n).tolist(),
            "Segment":  rng.choice(["Enterprise","SMB","Startup","Consumer"], n).tolist(),
        })

    if "PNL_BRIDGE" in u:
        return pd.DataFrame({
            "Item":  ["Opening","New Sales","Upsell","Churn","Refunds","OpEx","Closing"],
            "Delta": [120000, 52000, 21000, -18500, -7200, -38000, 0],
        })

    if "COST_SUNBURST" in u:
        return pd.DataFrame({
            "CostCategory": ["Personnel","Personnel","Personnel",
                             "Infrastructure","Infrastructure",
                             "Sales & Mktg","Sales & Mktg","Sales & Mktg",
                             "R&D","R&D",
                             "G&A","G&A"],
            "CostItem":     ["Salaries","Benefits","Contractors",
                             "Cloud","Office",
                             "Advertising","Events","Commissions",
                             "Engineering","Research",
                             "Legal","Finance"],
            "Amount":       [28000,6500,4200,
                             8800,3200,
                             7400,3100,5600,
                             9200,4100,
                             2800,1900],
        })

    if "EXPENSE_BREAKDOWN" in u:
        return pd.DataFrame({
            "ExpenseType": ["Personnel","Infrastructure","Sales & Mktg","R&D","G&A"],
            "Amount":      [38700, 12000, 16100, 13300, 4700],
        })

    return pd.DataFrame()


# ══════════════════════════════════════════════════════════════════════
# 3.  SQL BUILDER
# ══════════════════════════════════════════════════════════════════════

def build_select(cfg: dict) -> str:
    y_cols = cfg["y_columns"][:]
    # scatter may have a size/category column stored as 3rd+ y_column
    all_cols = [cfg["x_column"]] + y_cols
    # de-dup while preserving order
    seen, uniq = set(), []
    for c in all_cols:
        if c not in seen:
            seen.add(c); uniq.append(c)
    sql = f"SELECT {', '.join(uniq)}\nFROM   `{cfg['bq_table']}`"
    f   = cfg.get("filters","").strip()
    if f:
        sql += f"\nWHERE  {f}"
    return sql


# ══════════════════════════════════════════════════════════════════════
# 4.  CONFIG PARSER
# ══════════════════════════════════════════════════════════════════════

def parse_config(row: dict) -> dict:
    y = [c.strip() for c in str(row.get("y_columns","")).split(",") if c.strip()]
    return {
        "variable_name":  str(row.get("variable_name","")).strip(),
        "chart_type":     str(row.get("chart_type","bar")).lower().strip(),
        "bq_table":       str(row.get("bq_table","")).strip(),
        "filters":        str(row.get("filters","")).strip(),
        "x_column":       str(row.get("x_column","")).strip(),
        "y_columns":      y,
        "legend":         str(row.get("legend","yes")).lower() == "yes",
        "title":          str(row.get("title","")).strip(),
        "subtitle":       str(row.get("subtitle","")).strip(),
        "color_theme":    str(row.get("color_theme","default")).lower().strip(),
        "show_values":    str(row.get("show_values","no")).lower() == "yes",
        "sort_order":     str(row.get("sort_order","none")).lower().strip(),
        "width_px":       int(row.get("width_px", 600)),
        "height_px":      int(row.get("height_px", 320)),
        "ref_line_value": str(row.get("ref_line_value","")).strip(),
        "ref_line_label": str(row.get("ref_line_label","")).strip(),
        "x_label":        str(row.get("x_label","")).strip(),
        "y_label":        str(row.get("y_label","")).strip(),
        "dark_mode":      str(row.get("dark_mode","no")).lower() == "yes",
    }


# ══════════════════════════════════════════════════════════════════════
# 5.  DESIGN SYSTEM  —  v7
# ══════════════════════════════════════════════════════════════════════

# ── Typography ────────────────────────────────────────────────────────
FONT_FAMILY   = "DejaVu Sans"
TITLE_SIZE    = 11.0
SUBTITLE_SIZE = 8.5
LABEL_SIZE    = 8.0
TICK_SIZE     = 7.5
ANNOT_SIZE    = 7.0
LEGEND_SIZE   = 8.0

# ── Light-mode tokens ─────────────────────────────────────────────────
_LIGHT = dict(
    BG         = "#FFFFFF",
    CHART_BG   = "#FAFBFE",
    LEGEND_BG  = "#F4F6FB",
    GRID       = "#ECEEF5",
    BORDER     = "#DDE2EE",
    SEPARATOR  = "#D0D6E8",
    TEXT       = "#111827",
    MUTED      = "#6B7894",
    ACCENT_BAR = "#EBF0FA",
    ZERO_LINE  = "#C5CCDB",
    REF_LINE   = "#F59E0B",
    POS_COLOR  = "#059669",
    NEG_COLOR  = "#E11D48",
    TOTAL_COLOR= "#2563EB",
)

# ── Dark-mode tokens ──────────────────────────────────────────────────
_DARK = dict(
    BG         = "#0F172A",
    CHART_BG   = "#1E293B",
    LEGEND_BG  = "#162032",
    GRID       = "#293548",
    BORDER     = "#334155",
    SEPARATOR  = "#475569",
    TEXT       = "#F1F5F9",
    MUTED      = "#94A3B8",
    ACCENT_BAR = "#1E3A5F",
    ZERO_LINE  = "#475569",
    REF_LINE   = "#FBBF24",
    POS_COLOR  = "#10B981",
    NEG_COLOR  = "#F43F5E",
    TOTAL_COLOR= "#3B82F6",
)

DPI           = 220   # balanced resolution vs file size
LEGEND_H_IN   = 0.40

# Active tokens (set per-render via _tokens(dark_mode))
def _tokens(dark: bool = False) -> dict:
    return _DARK if dark else _LIGHT

# ── Colour palettes ───────────────────────────────────────────────────
# Each theme: [light variant list, dark variant list]
_PALETTES = {
    "blue":    (["#2563EB","#60A5FA","#93C5FD","#1E3A8A","#3B82F6","#BFDBFE"],
                ["#60A5FA","#93C5FD","#3B82F6","#BFDBFE","#2563EB","#DBEAFE"]),
    "cool":    (["#2563EB","#7C3AED","#0891B2","#059669","#D97706","#9333EA"],
                ["#60A5FA","#A78BFA","#22D3EE","#34D399","#FCD34D","#C084FC"]),
    "warm":    (["#EA580C","#D97706","#DB2777","#9333EA","#DC2626","#F59E0B"],
                ["#FB923C","#FBBF24","#F472B6","#C084FC","#F87171","#FDE68A"]),
    "vibrant": (["#2563EB","#059669","#D97706","#E11D48","#7C3AED","#0891B2"],
                ["#60A5FA","#34D399","#FCD34D","#FB7185","#A78BFA","#22D3EE"]),
    "teal":    (["#0F766E","#14B8A6","#2DD4BF","#0D9488","#134E4A","#5EEAD4"],
                ["#2DD4BF","#14B8A6","#5EEAD4","#99F6E4","#0D9488","#CCFBF1"]),
    "green":   (["#059669","#16A34A","#22C55E","#4ADE80","#14532D","#86EFAC"],
                ["#34D399","#22C55E","#86EFAC","#BBF7D0","#16A34A","#DCFCE7"]),
    "purple":  (["#7C3AED","#9333EA","#A78BFA","#6D28D9","#4C1D95","#C4B5FD"],
                ["#A78BFA","#C084FC","#DDD6FE","#8B5CF6","#7C3AED","#EDE9FE"]),
    "slate":   (["#334155","#475569","#64748B","#0F172A","#1E293B","#94A3B8"],
                ["#94A3B8","#CBD5E1","#64748B","#E2E8F0","#475569","#F1F5F9"]),
    "default": (["#2563EB","#059669","#D97706","#E11D48","#7C3AED","#0891B2"],
                ["#60A5FA","#34D399","#FCD34D","#FB7185","#A78BFA","#22D3EE"]),
    "rainbow": (["#2563EB","#059669","#D97706","#E11D48","#7C3AED","#0891B2"],
                ["#60A5FA","#34D399","#FCD34D","#FB7185","#A78BFA","#22D3EE"]),
}

def _palette(theme: str, n: int, dark: bool = False) -> list:
    entry = _PALETTES.get(theme, _PALETTES["default"])
    p     = entry[1] if dark else entry[0]
    return [p[i % len(p)] for i in range(n)]

def _inches(w_px: int, h_px: int):
    return (w_px / DPI, h_px / DPI)

def _smart_fmt(v: float) -> str:
    if abs(v) >= 1_000_000:
        return f"{v/1_000_000:.1f}M"
    if abs(v) >= 1_000:
        return f"{v/1_000:.0f}K"
    return f"{v:,.0f}"

def _wrap_labels(labels: list, maxlen: int = 12) -> list:
    """Word-wrap long category labels and auto-rotate if any are long."""
    return ["\n".join(textwrap.wrap(str(l), maxlen)) for l in labels]

def _smart_xticks(ax, labels: list, rotation_threshold: int = 6):
    """Reduce tick density and auto-rotate on dense axes."""
    n = len(labels)
    # Thin out if > 14 ticks
    if n > 14:
        step   = max(1, n // 8)
        ticks  = list(range(0, n, step))
        labels = [labels[i] for i in ticks]
        ax.set_xticks(ticks)
    else:
        ax.set_xticks(range(n))
    rot = 30 if n > rotation_threshold else 0
    wrapped = _wrap_labels(labels, maxlen=10) if rot == 0 else labels
    ax.set_xticklabels(wrapped, rotation=rot,
                       ha="right" if rot else "center",
                       color=_tokens().__class__)   # placeholder — overridden below

def _to_b64(fig) -> str:
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", UserWarning)
        fig.tight_layout(pad=0.4)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=DPI, bbox_inches="tight",
                facecolor=fig.get_facecolor(), edgecolor="none")
    buf.seek(0)
    b64 = base64.b64encode(buf.read()).decode()
    plt.close(fig)
    return f"data:image/png;base64,{b64}"


# ── Figure factory ────────────────────────────────────────────────────

def _make_fig(w_px: int, h_px: int, n_legend_items: int = 0,
              legend_ncols: int = 1, show_legend: bool = False,
              dark: bool = False):
    """
    Returns (fig, ax_chart, ax_legend_or_None).
    Legend gets its own axes below a hairline rule.
    Chart area has inner padding so content never touches the border.
    """
    T          = _tokens(dark)
    chart_h_in = h_px / DPI
    w_in       = w_px / DPI

    # Inner margins (fraction of figure): left, bottom, right, top
    L, R, T_m, B_m = 0.10, 0.04, 0.04, 0.10   # tighter sides, more room top/bottom

    if show_legend and n_legend_items > 0:
        n_rows   = max(1, -(-n_legend_items // max(legend_ncols, 1)))
        leg_h_in = LEGEND_H_IN * n_rows
        total_h  = chart_h_in + leg_h_in
        chart_r  = chart_h_in / total_h
        leg_r    = leg_h_in   / total_h

        fig      = plt.figure(figsize=(w_in, total_h))
        # chart axes sits above legend
        ax_chart = fig.add_axes([L, leg_r + B_m * leg_r, 1 - L - R,
                                  chart_r - T_m * chart_r - B_m * leg_r])
        ax_leg   = fig.add_axes([0, 0, 1, leg_r])
    else:
        fig      = plt.figure(figsize=(w_in, chart_h_in))
        ax_chart = fig.add_axes([L, B_m, 1 - L - R, 1 - T_m - B_m])
        ax_leg   = None

    fig.patch.set_facecolor(T["BG"])
    ax_chart.set_facecolor(T["CHART_BG"])
    for spine in ax_chart.spines.values():
        spine.set_visible(False)

    if ax_leg is not None:
        ax_leg.set_facecolor(T["LEGEND_BG"])
        for spine in ax_leg.spines.values():
            spine.set_visible(False)
        # subtle top separator line using plot instead of axhline
        ax_leg.plot([0, 1], [0.99, 0.99], color=T["SEPARATOR"], linewidth=0.6,
                    transform=ax_leg.transAxes, clip_on=False)

    return fig, ax_chart, ax_leg


def _populate_legend(ax_leg, handles: list, labels: list,
                     ncols: int = 4, dark: bool = False):
    """
    Render a pill-chip legend band.  Pill = rounded rect swatch + label.
    """
    if ax_leg is None or not handles:
        return
    T = _tokens(dark)
    ax_leg.set_xlim(0, 1)
    ax_leg.set_ylim(0, 1)
    ax_leg.axis("off")

    n     = len(labels)
    ncols = min(ncols, n)
    nrows = -(-n // ncols)
    col_w = 1.0 / ncols

    for idx, (h, lbl) in enumerate(zip(handles, labels)):
        col   = idx % ncols
        row   = idx // ncols
        y_pos = 1.0 - (row + 0.5) / nrows

        x_start  = col * col_w
        pill_x   = x_start + col_w * 0.04
        text_x   = pill_x + col_w * 0.13

        clr = h.get_facecolor() if hasattr(h, "get_facecolor") else h.get_color()
        if isinstance(clr, np.ndarray):
            clr = tuple(clr)

        # Pill-shaped swatch
        pill = FancyBboxPatch(
            (pill_x, y_pos - 0.018),
            col_w * 0.085, 0.036,
            boxstyle="round,pad=0.005,rounding_size=0.012",
            facecolor=clr, edgecolor="none",
            transform=ax_leg.transData, zorder=5,
        )
        ax_leg.add_patch(pill)

        ax_leg.text(
            text_x, y_pos, lbl,
            va="center", ha="left",
            fontsize=LEGEND_SIZE, color=T["MUTED"],
            fontfamily=FONT_FAMILY,
            transform=ax_leg.transData,
        )


# ── Shared axis helpers ───────────────────────────────────────────────

def _apply_grid(ax, axis="y", dark: bool = False):
    T = _tokens(dark)
    if axis == "y":
        ax.yaxis.grid(True, color=T["GRID"], linewidth=0.4, linestyle="-", zorder=0, alpha=0.8)
        ax.xaxis.grid(False)
    elif axis == "x":
        ax.xaxis.grid(True, color=T["GRID"], linewidth=0.4, linestyle="-", zorder=0, alpha=0.8)
        ax.yaxis.grid(False)
    ax.set_axisbelow(True)

def _style_ticks(ax, xtick_labels=None, rotation=0, dark: bool = False):
    T = _tokens(dark)
    ax.tick_params(axis="both", colors=T["MUTED"], labelsize=TICK_SIZE,
                   length=0, pad=5)
    if xtick_labels is not None:
        n   = len(xtick_labels)
        rot = rotation or (30 if n > 7 else 0)
        wrapped = ["\n".join(textwrap.wrap(str(l), 10)) for l in xtick_labels] \
                  if rot == 0 else xtick_labels
        ax.set_xticklabels(wrapped, color=T["MUTED"], fontsize=TICK_SIZE,
                           rotation=rot, ha="right" if rot else "center")
    ax.yaxis.set_tick_params(labelcolor=T["MUTED"], labelsize=TICK_SIZE)

def _draw_title(ax, title: str, subtitle: str = "", accent_color: str = None,
                dark: bool = False):
    """Title in bold dark text + subtitle in muted smaller text, cleanly separated."""
    T = _tokens(dark)

    # Draw a short left accent bar at the very top of axes
    if accent_color:
        ax.plot([0, 0.045], [1.0, 1.0], color=accent_color, linewidth=3.0,
                transform=ax.transAxes, clip_on=False, zorder=10,
                solid_capstyle="round")

    if subtitle:
        # Two-line: title first, subtitle below in muted smaller text
        ax.set_title(title, fontsize=TITLE_SIZE, fontweight="bold",
                     color=T["TEXT"], pad=6, loc="left",
                     fontfamily=FONT_FAMILY)
        # Place subtitle just below via annotation on axes coords
        ax.annotate(subtitle,
                    xy=(0, 1), xycoords="axes fraction",
                    xytext=(0, -14), textcoords="offset points",
                    fontsize=SUBTITLE_SIZE, color=T["MUTED"],
                    fontfamily=FONT_FAMILY, va="top", ha="left",
                    annotation_clip=False)
    else:
        ax.set_title(title, fontsize=TITLE_SIZE, fontweight="bold",
                     color=T["TEXT"], pad=8, loc="left",
                     fontfamily=FONT_FAMILY)

def _draw_axis_labels(ax, x_label: str = "", y_label: str = "",
                      dark: bool = False):
    T = _tokens(dark)
    if x_label:
        ax.set_xlabel(x_label, fontsize=LABEL_SIZE, color=T["MUTED"],
                      fontfamily=FONT_FAMILY, labelpad=6)
    if y_label:
        ax.set_ylabel(y_label, fontsize=LABEL_SIZE, color=T["MUTED"],
                      fontfamily=FONT_FAMILY, labelpad=6)

def _draw_ref_line(ax, cfg: dict, dark: bool = False):
    """Draw a horizontal reference / threshold line if configured."""
    T = _tokens(dark)
    rv = cfg.get("ref_line_value","").strip()
    rl = cfg.get("ref_line_label","").strip()
    if not rv:
        return
    try:
        val = float(rv)
    except ValueError:
        return
    ax.axhline(val, color=T["REF_LINE"], linewidth=1.2,
               linestyle="--", zorder=5, alpha=0.85)
    if rl:
        ax.text(
            0.01, val, f" {rl}",
            transform=ax.get_yaxis_transform(),
            fontsize=ANNOT_SIZE, color=T["REF_LINE"],
            va="bottom", fontfamily=FONT_FAMILY,
        )

def _draw_zero_line(ax, dark: bool = False):
    T = _tokens(dark)
    ax.axhline(0, color=T["ZERO_LINE"], linewidth=0.8, zorder=3)

def _draw_legend(ax, handles=None, labels=None, loc="upper left"):
    """Stub — kept for backwards compat.  v7 uses _populate_legend."""
    pass


# ══════════════════════════════════════════════════════════════════════
# 6.  CHART RENDERERS  —  v7
# ══════════════════════════════════════════════════════════════════════

# ── LINE CHART ────────────────────────────────────────────────────────
def _line(df: pd.DataFrame, cfg: dict) -> str:
    dark  = cfg.get("dark_mode", False)
    T     = _tokens(dark)
    cols  = cfg["y_columns"]
    clrs  = _palette(cfg["color_theme"], len(cols), dark)
    show_leg = cfg["legend"] and len(cols) > 1

    fig, ax, ax_leg = _make_fig(
        cfg["width_px"], cfg["height_px"],
        n_legend_items=len(cols) if show_leg else 0,
        legend_ncols=min(4, len(cols)),
        show_legend=show_leg, dark=dark,
    )
    _apply_grid(ax, dark=dark)

    x       = np.arange(len(df))
    handles = []

    for i, col in enumerate(cols):
        if col not in df.columns:
            continue
        c = clrs[i]
        y = df[col].values.astype(float)

        # Gradient fill under line
        ax.fill_between(x, y, alpha=0.08, color=c, zorder=2)

        # Main line - smooth, thicker
        ax.plot(x, y, color=c, linewidth=2.2, zorder=4,
                solid_capstyle="round", solid_joinstyle="round")

        # Dot markers: white fill with color border
        ax.plot(x, y, "o", color=c, markersize=5.5, zorder=5,
                markerfacecolor="#FFFFFF" if not dark else T["CHART_BG"],
                markeredgecolor=c, markeredgewidth=1.8)

        if cfg["show_values"]:
            for xi, yi in zip(x, y):
                ax.annotate(_smart_fmt(yi), (xi, yi),
                            textcoords="offset points", xytext=(0, 10),
                            ha="center", fontsize=ANNOT_SIZE,
                            color=c, fontweight="bold")
        handles.append(mpatches.Patch(color=c, label=col))

    ax.set_xticks(x)
    _style_ticks(ax, xtick_labels=df[cfg["x_column"]].tolist(), dark=dark)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: _smart_fmt(v)))
    ax.set_xlim(-0.6, len(x) - 0.4)

    yvals = [df[c].values for c in cols if c in df.columns]
    if yvals:
        ymin = min(v.min() for v in yvals)
        ymax = max(v.max() for v in yvals)
        pad  = (ymax - ymin) * 0.22
        ax.set_ylim(max(0, ymin - pad * 0.4), ymax + pad)

    _draw_ref_line(ax, cfg, dark)
    _draw_title(ax, cfg["title"], cfg.get("subtitle",""), accent_color=clrs[0], dark=dark)
    _draw_axis_labels(ax, cfg.get("x_label",""), cfg.get("y_label",""), dark)

    if show_leg and ax_leg:
        _populate_legend(ax_leg, handles, cols, ncols=min(4, len(cols)), dark=dark)

    return _to_b64(fig)


# ── BAR CHART ─────────────────────────────────────────────────────────
def _bar(df: pd.DataFrame, cfg: dict) -> str:
    dark  = cfg.get("dark_mode", False)
    T     = _tokens(dark)
    cols  = cfg["y_columns"]
    clrs  = _palette(cfg["color_theme"], len(cols), dark)
    show_leg = cfg["legend"] and len(cols) > 1

    fig, ax, ax_leg = _make_fig(
        cfg["width_px"], cfg["height_px"],
        n_legend_items=len(cols) if show_leg else 0,
        legend_ncols=min(4, len(cols)),
        show_legend=show_leg, dark=dark,
    )
    _apply_grid(ax, dark=dark)

    x       = np.arange(len(df))
    n       = len(cols)
    total_w = 0.68
    w       = total_w / max(n, 1)
    gap     = w * 0.12          # small gap between grouped bars
    handles = []

    for i, col in enumerate(cols):
        if col not in df.columns:
            continue
        c       = clrs[i]
        offsets = x + (i - n / 2 + 0.5) * (w + gap * (1 / max(n, 1)))
        vals    = df[col].values.astype(float)
        ymax_v  = vals.max()

        for xi, yi in zip(offsets, vals):
            bar_h    = max(yi, 0)
            rounding = min(0.018, (w - gap) * 0.22)

            rect = FancyBboxPatch(
                (xi - (w - gap) * 0.5, 0), w - gap, bar_h,
                boxstyle=f"round,pad=0,rounding_size={rounding}",
                facecolor=c, edgecolor="none", zorder=3, alpha=0.88,
            )
            ax.add_patch(rect)

            if cfg["show_values"] and bar_h > 0:
                ax.text(xi, bar_h + ymax_v * 0.012,
                        _smart_fmt(bar_h),
                        ha="center", va="bottom",
                        fontsize=ANNOT_SIZE, color=c, fontweight="bold")

        handles.append(mpatches.Patch(color=c, label=col))

    ax.set_xlim(-0.6, len(x) - 0.4)
    all_vals = np.concatenate([df[c].values for c in cols if c in df.columns])
    ymax_all = all_vals.max()
    ax.set_ylim(0, ymax_all * 1.20)

    ax.set_xticks(x)
    _style_ticks(ax, xtick_labels=df[cfg["x_column"]].tolist(), dark=dark)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: _smart_fmt(v)))

    _draw_ref_line(ax, cfg, dark)
    _draw_title(ax, cfg["title"], cfg.get("subtitle",""), accent_color=clrs[0], dark=dark)
    _draw_axis_labels(ax, cfg.get("x_label",""), cfg.get("y_label",""), dark)

    if show_leg and ax_leg:
        _populate_legend(ax_leg, handles,
                         [c for c in cols if c in df.columns],
                         ncols=min(4, len(cols)), dark=dark)

    return _to_b64(fig)


# ── PIE CHART ─────────────────────────────────────────────────────────
def _pie(df: pd.DataFrame, cfg: dict) -> str:
    dark = cfg.get("dark_mode", False)
    T    = _tokens(dark)

    if cfg["sort_order"] == "desc":
        df = df.sort_values(cfg["y_columns"][0], ascending=False).reset_index(drop=True)
    elif cfg["sort_order"] == "asc":
        df = df.sort_values(cfg["y_columns"][0], ascending=True).reset_index(drop=True)

    val_col = cfg["y_columns"][0]
    lbl_col = cfg["x_column"]
    labels  = df[lbl_col].tolist()
    values  = df[val_col].tolist()
    total   = sum(values)
    clrs    = _palette(cfg["color_theme"], len(labels), dark)

    show_leg = cfg["legend"]
    fig, ax, ax_leg = _make_fig(
        cfg["width_px"], cfg["height_px"],
        n_legend_items=len(labels) if show_leg else 0,
        legend_ncols=min(3, len(labels)),
        show_legend=show_leg, dark=dark,
    )
    ax.set_facecolor(T["BG"])

    wedges, _ = ax.pie(
        values,
        colors=clrs,
        explode=[0.015] * len(labels),
        startangle=90,
        wedgeprops={"linewidth": 2.5, "edgecolor": T["BG"]},
        labels=None,
        autopct=None,
        radius=0.85,
    )

    if cfg["show_values"]:
        # Place labels at adaptive radii to avoid overlap
        for i, (wedge, val, lbl) in enumerate(zip(wedges, values, labels)):
            angle  = (wedge.theta1 + wedge.theta2) / 2
            rad    = np.deg2rad(angle)
            pct    = val / total * 100
            # Push small slices further out
            r_out  = 1.10 + (0.15 if pct < 7 else 0.02)
            x_tip  = 0.60 * np.cos(rad)
            y_tip  = 0.60 * np.sin(rad)
            x_lbl  = r_out * 0.85 * np.cos(rad)
            y_lbl  = r_out * 0.85 * np.sin(rad)

            ha = "left" if x_lbl > 0.05 else ("right" if x_lbl < -0.05 else "center")

            ax.annotate(
                f"{pct:.1f}%",
                xy=(x_tip, y_tip),
                xytext=(x_lbl, y_lbl),
                ha=ha, va="center",
                fontsize=ANNOT_SIZE + 0.5, fontweight="bold",
                color=clrs[i],
                arrowprops=dict(arrowstyle="-", color=T["SEPARATOR"], lw=0.8,
                                shrinkA=2, shrinkB=2),
            )

    ax.set_xlim(-1.55, 1.55)
    ax.set_ylim(-1.55, 1.55)

    if cfg.get("subtitle"):
        ax.set_title(f"{cfg['title']}", fontsize=TITLE_SIZE, fontweight="bold",
                     color=T["TEXT"], pad=6, loc="left", fontfamily=FONT_FAMILY)
        ax.annotate(cfg["subtitle"], xy=(0, 1), xycoords="axes fraction",
                    xytext=(0, -12), textcoords="offset points",
                    fontsize=SUBTITLE_SIZE, color=T["MUTED"],
                    fontfamily=FONT_FAMILY, va="top", ha="left", annotation_clip=False)
    else:
        ax.set_title(cfg["title"], fontsize=TITLE_SIZE, fontweight="bold",
                     color=T["TEXT"], pad=8, loc="left", fontfamily=FONT_FAMILY)

    if show_leg and ax_leg:
        handles = [mpatches.Patch(color=clrs[i],
                                  label=f"{lbl}  {_smart_fmt(values[i])}")
                   for i, lbl in enumerate(labels)]
        _populate_legend(ax_leg, handles,
                         [f"{lbl}  {_smart_fmt(values[i])}" for i, lbl in enumerate(labels)],
                         ncols=min(3, len(labels)), dark=dark)

    return _to_b64(fig)


# ── DONUT CHART ───────────────────────────────────────────────────────
def _donut(df: pd.DataFrame, cfg: dict) -> str:
    dark = cfg.get("dark_mode", False)
    T    = _tokens(dark)

    if cfg["sort_order"] == "desc":
        df = df.sort_values(cfg["y_columns"][0], ascending=False).reset_index(drop=True)
    elif cfg["sort_order"] == "asc":
        df = df.sort_values(cfg["y_columns"][0], ascending=True).reset_index(drop=True)

    val_col = cfg["y_columns"][0]
    lbl_col = cfg["x_column"]
    labels  = df[lbl_col].tolist()
    values  = df[val_col].tolist()
    total   = sum(values)
    clrs    = _palette(cfg["color_theme"], len(labels), dark)

    show_leg = cfg["legend"]
    fig, ax, ax_leg = _make_fig(
        cfg["width_px"], cfg["height_px"],
        n_legend_items=len(labels) if show_leg else 0,
        legend_ncols=min(3, len(labels)),
        show_legend=show_leg, dark=dark,
    )
    ax.set_facecolor(T["BG"])

    wedges, _ = ax.pie(
        values,
        colors=clrs,
        startangle=90,
        wedgeprops={"linewidth": 2.8, "edgecolor": T["BG"], "width": 0.44},
        labels=None,
        autopct=None,
    )

    if cfg["show_values"]:
        for wedge, val in zip(wedges, values):
            angle = (wedge.theta1 + wedge.theta2) / 2
            rad   = np.deg2rad(angle)
            rm    = 1 - 0.44 / 2
            xi    = rm * np.cos(rad) * 0.80
            yi    = rm * np.sin(rad) * 0.80
            pct   = f"{val/total*100:.0f}%"
            ax.text(xi, yi, pct, ha="center", va="center",
                    fontsize=ANNOT_SIZE, fontweight="bold", color=T["BG"])

    # Centre KPI — bold value + muted label
    ax.text(0,  0.12, _smart_fmt(values[0]),
            ha="center", va="center",
            fontsize=13, fontweight="bold",
            color=T["TEXT"], fontfamily=FONT_FAMILY)
    ax.text(0, -0.15, labels[0],
            ha="center", va="center",
            fontsize=LABEL_SIZE - 0.5, color=T["MUTED"], fontfamily=FONT_FAMILY)

    if cfg.get("subtitle"):
        ax.set_title(cfg["title"], fontsize=TITLE_SIZE, fontweight="bold",
                     color=T["TEXT"], pad=6, loc="left", fontfamily=FONT_FAMILY)
        ax.annotate(cfg["subtitle"], xy=(0, 1), xycoords="axes fraction",
                    xytext=(0, -12), textcoords="offset points",
                    fontsize=SUBTITLE_SIZE, color=T["MUTED"],
                    fontfamily=FONT_FAMILY, va="top", ha="left", annotation_clip=False)
    else:
        ax.set_title(cfg["title"], fontsize=TITLE_SIZE, fontweight="bold",
                     color=T["TEXT"], pad=8, loc="left", fontfamily=FONT_FAMILY)

    if show_leg and ax_leg:
        handles = [mpatches.Patch(color=clrs[i],
                                  label=f"{lbl}  {values[i]:.1f}%")
                   for i, lbl in enumerate(labels)]
        _populate_legend(ax_leg, handles,
                         [f"{lbl}  {values[i]:.1f}%" for i, lbl in enumerate(labels)],
                         ncols=min(3, len(labels)), dark=dark)

    return _to_b64(fig)


# ── AREA CHART ────────────────────────────────────────────────────────
def _area(df: pd.DataFrame, cfg: dict) -> str:
    dark  = cfg.get("dark_mode", False)
    T     = _tokens(dark)
    cols  = cfg["y_columns"]
    clrs  = _palette(cfg["color_theme"], len(cols), dark)
    show_leg = cfg["legend"] and len(cols) > 1

    fig, ax, ax_leg = _make_fig(
        cfg["width_px"], cfg["height_px"],
        n_legend_items=len(cols) if show_leg else 0,
        legend_ncols=min(4, len(cols)),
        show_legend=show_leg, dark=dark,
    )
    _apply_grid(ax, dark=dark)

    x       = np.arange(len(df))
    handles = []

    for i, col in enumerate(reversed(cols)):
        if col not in df.columns:
            continue
        c = clrs[len(cols) - 1 - i]
        y = df[col].values.astype(float)

        ax.fill_between(x, y, alpha=0.20, color=c, zorder=2 + i)
        ax.plot(x, y, color=c, linewidth=2.0, zorder=4 + i,
                solid_capstyle="round")
        handles.insert(0, mpatches.Patch(color=c, label=col))

        if cfg["show_values"]:
            for xi, yi in zip(x, y):
                ax.annotate(_smart_fmt(yi), (xi, yi),
                            textcoords="offset points", xytext=(0, 8),
                            ha="center", fontsize=ANNOT_SIZE - 0.5,
                            color=c, fontweight="bold")

    ax.set_xticks(x)
    _style_ticks(ax, xtick_labels=df[cfg["x_column"]].tolist(), dark=dark)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: _smart_fmt(v)))
    ax.set_xlim(-0.4, len(x) - 0.6)
    ax.set_ylim(0)

    _draw_ref_line(ax, cfg, dark)
    _draw_title(ax, cfg["title"], cfg.get("subtitle",""), accent_color=clrs[0], dark=dark)
    _draw_axis_labels(ax, cfg.get("x_label",""), cfg.get("y_label",""), dark)

    if show_leg and ax_leg:
        _populate_legend(ax_leg, handles,
                         [h.get_label() for h in handles],
                         ncols=min(4, len(cols)), dark=dark)

    return _to_b64(fig)


# ── HORIZONTAL BAR CHART ─────────────────────────────────────────────
def _hbar(df: pd.DataFrame, cfg: dict) -> str:
    dark = cfg.get("dark_mode", False)
    T    = _tokens(dark)

    val_col = cfg["y_columns"][0]
    lbl_col = cfg["x_column"]

    if cfg["sort_order"] == "desc":
        df = df.sort_values(val_col, ascending=True).reset_index(drop=True)
    elif cfg["sort_order"] == "asc":
        df = df.sort_values(val_col, ascending=False).reset_index(drop=True)

    labels = df[lbl_col].tolist()
    values = df[val_col].values.astype(float)
    n      = len(labels)
    clrs   = _palette(cfg["color_theme"], 2, dark)

    h_px = max(cfg["height_px"], n * 46 + 80)
    fig, ax, _ = _make_fig(cfg["width_px"], h_px, show_legend=False, dark=dark)
    _apply_grid(ax, axis="x", dark=dark)

    y          = np.arange(n)
    vmax       = values.max()
    bar_colors = [clrs[0] if i == n - 1 else clrs[1] for i in range(n)]

    # Progress-track background (full-width faint bar)
    for yi in y:
        ax.barh(yi, vmax, height=0.52, color=T["ACCENT_BAR"],
                edgecolor="none", zorder=1, left=0)

    # Actual bars
    bars = ax.barh(y, values, height=0.52, color=bar_colors,
                   edgecolor="none", zorder=3)

    # Left accent pill
    pill_w = vmax * 0.009
    for yi, bc in zip(y, bar_colors):
        ax.barh(yi, pill_w, height=0.52, color=bc,
                edgecolor="none", zorder=5, left=0)

    # % completion text (faint, right-aligned within track)
    for yi, val in enumerate(values):
        pct = val / vmax * 100
        ax.text(vmax * 0.985, yi,
                f"{pct:.0f}%",
                va="center", ha="right",
                fontsize=ANNOT_SIZE - 0.5, color=T["MUTED"], alpha=0.6)

    # Value labels
    for bar, val, col_clr in zip(bars, values, bar_colors):
        ax.text(
            bar.get_width() + vmax * 0.015,
            bar.get_y() + bar.get_height() / 2,
            _smart_fmt(val),
            va="center", ha="left",
            fontsize=ANNOT_SIZE, color=col_clr, fontweight="bold",
        )

    ax.set_yticks(y)
    ax.set_yticklabels(labels, fontsize=TICK_SIZE + 0.5, color=T["TEXT"])
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: _smart_fmt(v)))
    ax.tick_params(axis="x", colors=T["MUTED"], labelsize=TICK_SIZE, length=0)
    ax.tick_params(axis="y", length=0, pad=8)
    ax.set_xlim(0, vmax * 1.24)

    _draw_title(ax, cfg["title"], cfg.get("subtitle",""), accent_color=clrs[0], dark=dark)
    _draw_axis_labels(ax, cfg.get("x_label",""), cfg.get("y_label",""), dark)
    return _to_b64(fig)


# ── SCATTER / BUBBLE CHART  (NEW) ─────────────────────────────────────
def _scatter(df: pd.DataFrame, cfg: dict) -> str:
    """
    Scatter / bubble chart.

    Config:
      x_column  — horizontal axis
      y_columns[0] — vertical axis
      y_columns[1] (optional) — bubble size column
      y_columns[2] (optional) — category column for colour-coding

    Points are jittered slightly if overlapping.
    """
    dark = cfg.get("dark_mode", False)
    T    = _tokens(dark)

    x_col    = cfg["x_column"]
    y_col    = cfg["y_columns"][0] if len(cfg["y_columns"]) > 0 else None
    size_col = cfg["y_columns"][1] if len(cfg["y_columns"]) > 1 else None
    cat_col  = cfg["y_columns"][2] if len(cfg["y_columns"]) > 2 else None

    if y_col is None or y_col not in df.columns:
        return None

    # Category colours
    categories = df[cat_col].unique().tolist() if cat_col and cat_col in df.columns else [None]
    clrs       = _palette(cfg["color_theme"], len(categories), dark)
    cat_map    = {c: clrs[i] for i, c in enumerate(categories)}

    show_leg = cfg["legend"] and cat_col is not None
    fig, ax, ax_leg = _make_fig(
        cfg["width_px"], cfg["height_px"],
        n_legend_items=len(categories) if show_leg else 0,
        legend_ncols=min(4, len(categories)),
        show_legend=show_leg, dark=dark,
    )
    _apply_grid(ax, dark=dark)

    handles = []
    for cat in categories:
        mask = (df[cat_col] == cat) if cat_col and cat_col in df.columns else pd.Series([True]*len(df))
        sub  = df[mask]

        xs   = sub[x_col].values.astype(float)
        ys   = sub[y_col].values.astype(float)
        clr  = cat_map.get(cat, clrs[0])

        if size_col and size_col in df.columns:
            raw_sizes = sub[size_col].values.astype(float)
            sizes     = 20 + (raw_sizes / raw_sizes.max()) * 200
        else:
            sizes = 60

        ax.scatter(xs, ys, s=sizes, c=clr, alpha=0.75,
                   edgecolors=T["BG"], linewidths=0.8, zorder=4)

        if cat is not None:
            handles.append(mpatches.Patch(color=clr, label=str(cat)))

    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: _smart_fmt(v)))
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: _smart_fmt(v)))
    ax.tick_params(axis="both", colors=T["MUTED"], labelsize=TICK_SIZE, length=0)

    _draw_ref_line(ax, cfg, dark)
    _draw_title(ax, cfg["title"], cfg.get("subtitle",""), accent_color=clrs[0], dark=dark)
    _draw_axis_labels(ax, cfg.get("x_label", x_col), cfg.get("y_label", y_col), dark)

    if show_leg and ax_leg and handles:
        _populate_legend(ax_leg, handles, [h.get_label() for h in handles],
                         ncols=min(4, len(handles)), dark=dark)

    return _to_b64(fig)


# ── COMBO CHART: Bar + Line  (NEW) ───────────────────────────────────
def _combo(df: pd.DataFrame, cfg: dict) -> str:
    """
    Dual-axis combo chart: first y_column as bars, remaining as lines.
    Secondary y-axis is auto-scaled independently.
    """
    dark  = cfg.get("dark_mode", False)
    T     = _tokens(dark)
    cols  = cfg["y_columns"]
    if len(cols) < 2:
        return _bar(df, cfg)   # fallback

    bar_col  = cols[0]
    line_cols = cols[1:]
    clrs     = _palette(cfg["color_theme"], len(cols), dark)
    show_leg = cfg["legend"]

    n_leg = len(cols) if show_leg else 0
    fig, ax, ax_leg = _make_fig(
        cfg["width_px"], cfg["height_px"],
        n_legend_items=n_leg,
        legend_ncols=min(4, n_leg),
        show_legend=show_leg, dark=dark,
    )
    _apply_grid(ax, dark=dark)

    x        = np.arange(len(df))
    bar_vals = df[bar_col].values.astype(float) if bar_col in df.columns else np.zeros(len(df))
    w        = 0.60

    # Bars (primary y-axis)
    for xi, yi in zip(x, bar_vals):
        rounding = min(0.025, w * 0.25)
        patch = FancyBboxPatch(
            (xi - w/2, 0), w, max(yi, 0),
            boxstyle=f"round,pad=0,rounding_size={rounding}",
            facecolor=clrs[0], edgecolor="none", zorder=3, alpha=0.82,
        )
        ax.add_patch(patch)

    ax.set_xlim(-0.6, len(x) - 0.4)
    ax.set_ylim(0, bar_vals.max() * 1.25)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: _smart_fmt(v)))
    ax.set_xticks(x)
    _style_ticks(ax, xtick_labels=df[cfg["x_column"]].tolist(), dark=dark)
    ax.tick_params(axis="y", colors=clrs[0], labelsize=TICK_SIZE)

    # Secondary y-axis for lines
    ax2 = ax.twinx()
    ax2.set_facecolor("none")
    for spine in ax2.spines.values():
        spine.set_visible(False)

    handles = [mpatches.Patch(color=clrs[0], label=bar_col)]

    for i, col in enumerate(line_cols):
        if col not in df.columns:
            continue
        c = clrs[i + 1]
        y = df[col].values.astype(float)

        ax2.plot(x, y, color=c, linewidth=2.0, zorder=6,
                 marker="o", markersize=4.0,
                 markerfacecolor=T["BG"], markeredgecolor=c, markeredgewidth=1.5,
                 solid_capstyle="round")
        handles.append(mpatches.Patch(color=c, label=col))

    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: _smart_fmt(v)))
    ax2.tick_params(axis="y", colors=T["MUTED"], labelsize=TICK_SIZE, length=0)

    _draw_ref_line(ax, cfg, dark)
    _draw_title(ax, cfg["title"], cfg.get("subtitle",""), accent_color=clrs[0], dark=dark)
    _draw_axis_labels(ax, cfg.get("x_label",""), cfg.get("y_label",""), dark)

    all_labels = [bar_col] + [c for c in line_cols if c in df.columns]
    if show_leg and ax_leg:
        _populate_legend(ax_leg, handles, all_labels, ncols=min(4, len(all_labels)), dark=dark)

    return _to_b64(fig)


# ── WATERFALL / BRIDGE CHART  (NEW) ──────────────────────────────────
def _waterfall(df: pd.DataFrame, cfg: dict) -> str:
    """
    Running-total waterfall (bridge) chart.

    Expects:
      x_column   — category / item labels
      y_columns[0] — delta values (positive = increase, negative = decrease)

    Last row can be a total (Delta=0 triggers auto-compute).
    Bars: positive=POS_COLOR, negative=NEG_COLOR, total=TOTAL_COLOR.
    """
    dark    = cfg.get("dark_mode", False)
    T       = _tokens(dark)
    lbl_col = cfg["x_column"]
    val_col = cfg["y_columns"][0] if cfg["y_columns"] else None

    if val_col is None or val_col not in df.columns:
        return None

    labels = df[lbl_col].tolist()
    deltas = df[val_col].values.astype(float)

    # Auto-compute last total if its delta is 0
    is_total  = np.zeros(len(deltas), dtype=bool)
    if deltas[-1] == 0:
        deltas[-1] = deltas[:-1].sum()
        is_total[-1] = True

    # Running bottom positions
    running = np.zeros(len(deltas) + 1)
    for i, d in enumerate(deltas):
        running[i + 1] = running[i] + d if not is_total[i] else running[i]

    bottoms = np.where(is_total, 0, np.minimum(running[:-1], running[:-1] + deltas))
    heights = np.abs(deltas)

    clrs = []
    for i, (d, tot) in enumerate(zip(deltas, is_total)):
        if tot:
            clrs.append(T["TOTAL_COLOR"])
        elif d >= 0:
            clrs.append(T["POS_COLOR"])
        else:
            clrs.append(T["NEG_COLOR"])

    fig, ax, _ = _make_fig(cfg["width_px"], cfg["height_px"],
                           show_legend=False, dark=dark)
    _apply_grid(ax, dark=dark)

    x = np.arange(len(labels))
    w = 0.55

    for xi, bot, h, clr, is_tot, dlt in zip(x, bottoms, heights, clrs, is_total, deltas):
        rounding = min(0.02, w * 0.25)
        patch = FancyBboxPatch(
            (xi - w/2, bot), w, max(h, 0),
            boxstyle=f"round,pad=0,rounding_size={rounding}",
            facecolor=clr, edgecolor="none", zorder=3, alpha=0.90,
        )
        ax.add_patch(patch)

        # Connector line to next bar
        if xi < len(labels) - 1 and not is_tot:
            end_val = bot + h if dlt >= 0 else bot
            ax.hlines(end_val, xi + w/2, xi + 1 - w/2,
                      colors=T["GRID"], linewidth=0.8, zorder=2)

        if cfg["show_values"]:
            sign = "+" if dlt > 0 and not is_tot else ""
            ax.text(xi, bot + h + heights.max() * 0.015,
                    f"{sign}{_smart_fmt(dlt)}",
                    ha="center", va="bottom",
                    fontsize=ANNOT_SIZE, color=clr, fontweight="bold")

    _draw_zero_line(ax, dark)
    ax.set_xticks(x)
    _style_ticks(ax, xtick_labels=labels, dark=dark)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda v,_: _smart_fmt(v)))

    all_vals = np.concatenate([bottoms, bottoms + heights])
    ypad     = (all_vals.max() - all_vals.min()) * 0.15
    ax.set_ylim(min(0, all_vals.min()) - ypad, all_vals.max() + ypad)

    _draw_title(ax, cfg["title"], cfg.get("subtitle",""), dark=dark)
    _draw_axis_labels(ax, cfg.get("x_label",""), cfg.get("y_label",""), dark)

    # Compact legend: green=increase, red=decrease, blue=total
    legend_items = [
        mpatches.Patch(color=T["POS_COLOR"], label="Increase"),
        mpatches.Patch(color=T["NEG_COLOR"], label="Decrease"),
        mpatches.Patch(color=T["TOTAL_COLOR"],label="Total"),
    ]
    ax.legend(handles=legend_items, loc="upper right",
              fontsize=LABEL_SIZE - 0.5,
              frameon=True, facecolor=T["BG"], edgecolor=T["BORDER"],
              framealpha=0.92)
    for text in ax.get_legend().get_texts():
        text.set_color(T["MUTED"])

    return _to_b64(fig)


# ── SUNBURST CHART  (NEW v10) ─────────────────────────────────────────
def _sunburst(df: pd.DataFrame, cfg: dict) -> str:
    """
    Two-level sunburst (parent → child breakdown).

    Required columns:
      x_column    — inner ring label  (e.g. "Category")
      y_columns[0] — value column     (e.g. "Revenue")
      y_columns[1] (optional) — child label column (e.g. "SubCategory")
                                If present, creates 2-ring sunburst.
                                If absent, renders single-ring sunburst.

    Config extras:
      show_values = yes  → percentage labels on each segment
      sort_order  = desc → sort parent segments by value descending

    Tip: In BigQuery, pre-aggregate so each row is one (parent, child) pair.
         The engine groups automatically if child column is provided.
    """
    dark     = cfg.get("dark_mode", False)
    T        = _tokens(dark)
    lbl_col  = cfg["x_column"]
    val_col  = cfg["y_columns"][0] if cfg["y_columns"] else None
    child_col = cfg["y_columns"][1] if len(cfg["y_columns"]) > 1 else None

    if val_col is None or val_col not in df.columns:
        return None

    # ── Aggregate parents ──────────────────────────────────────────────
    if cfg["sort_order"] == "desc":
        df = df.sort_values(val_col, ascending=False).reset_index(drop=True)

    parents    = df[lbl_col].tolist()
    par_vals   = df[val_col].values.astype(float)
    total      = par_vals.sum()
    n_parents  = len(parents)
    clrs_outer = _palette(cfg["color_theme"], n_parents, dark)

    show_leg  = cfg["legend"]
    fig, ax, ax_leg = _make_fig(
        cfg["width_px"], cfg["height_px"],
        n_legend_items=n_parents if show_leg else 0,
        legend_ncols=min(3, n_parents),
        show_legend=show_leg, dark=dark,
    )
    ax.set_facecolor(T["BG"])
    ax.set_xlim(-1.65, 1.65)
    ax.set_ylim(-1.65, 1.65)
    ax.set_aspect("equal")
    ax.axis("off")

    has_children = (
        child_col is not None
        and child_col in df.columns
        and df[child_col].nunique() > n_parents
    )

    # ── Ring radii ─────────────────────────────────────────────────────
    if has_children:
        r_inner_min, r_inner_max = 0.30, 0.68
        r_outer_min, r_outer_max = 0.72, 1.05
    else:
        r_inner_min, r_inner_max = 0.32, 1.05
        r_outer_min, r_outer_max = None, None   # unused

    # ── Draw inner (parent) ring ───────────────────────────────────────
    start_angle = 90.0          # start at top (12 o'clock)
    handles     = []
    par_angles  = []            # (start, end, colour) per parent

    for i, (lbl, val) in enumerate(zip(parents, par_vals)):
        frac       = val / total
        sweep      = frac * 360.0
        end_angle  = start_angle - sweep
        c          = clrs_outer[i]

        wedge = mpatches.Wedge(
            center=(0, 0),
            r=r_inner_max,
            theta1=end_angle, theta2=start_angle,
            width=r_inner_max - r_inner_min,
            facecolor=c, edgecolor=T["BG"], linewidth=1.8,
            zorder=3,
        )
        ax.add_patch(wedge)
        par_angles.append((start_angle, end_angle, c))

        # Label placement
        mid_rad   = np.deg2rad((start_angle + end_angle) / 2)
        r_mid     = (r_inner_min + r_inner_max) / 2
        tx, ty    = r_mid * np.cos(mid_rad), r_mid * np.sin(mid_rad)
        pct       = frac * 100

        if cfg["show_values"] and pct > 3.5:
            short_lbl = textwrap.shorten(str(lbl), width=10, placeholder="…")
            ax.text(tx, ty, f"{short_lbl}\n{pct:.1f}%",
                    ha="center", va="center",
                    fontsize=max(ANNOT_SIZE - 0.5, 6.0),
                    color="#FFFFFF", fontweight="bold",
                    fontfamily=FONT_FAMILY, zorder=5,
                    multialignment="center")

        handles.append(mpatches.Patch(color=c, label=f"{lbl}  {_smart_fmt(val)}"))
        start_angle = end_angle

    # ── Draw outer (child) ring ────────────────────────────────────────
    if has_children:
        for (par_start, par_end, par_clr), par_lbl in zip(par_angles, parents):
            sub_df   = df[df[lbl_col] == par_lbl].copy()
            sub_vals = sub_df[val_col].values.astype(float)
            sub_lbls = sub_df[child_col].tolist()
            sub_tot  = sub_vals.sum()
            if sub_tot == 0:
                continue

            # Lighter tints of parent colour for children
            import matplotlib.colors as mcolors
            base_rgba = np.array(mcolors.to_rgba(par_clr))
            n_ch      = len(sub_vals)

            ang = par_start
            for j, (cv, cl) in enumerate(zip(sub_vals, sub_lbls)):
                child_frac  = cv / sub_tot
                child_sweep = child_frac * (par_start - par_end)
                end_a       = ang - child_sweep

                # Tint: lighten toward white based on child index
                tint  = min(0.55, j / max(n_ch - 1, 1) * 0.55)
                child_rgba = base_rgba * (1 - tint) + np.array([1, 1, 1, 1]) * tint
                child_c    = mcolors.to_hex(child_rgba[:3])

                outer_w = mpatches.Wedge(
                    center=(0, 0),
                    r=r_outer_max, theta1=end_a, theta2=ang,
                    width=r_outer_max - r_outer_min,
                    facecolor=child_c,
                    edgecolor=T["BG"], linewidth=1.2, zorder=4,
                )
                ax.add_patch(outer_w)

                # Child label if large enough
                if cfg["show_values"] and child_frac > 0.08:
                    mid_r   = (r_outer_min + r_outer_max) / 2
                    mid_a   = np.deg2rad((ang + end_a) / 2)
                    ax.text(mid_r * np.cos(mid_a), mid_r * np.sin(mid_a),
                            textwrap.shorten(str(cl), width=8, placeholder="…"),
                            ha="center", va="center",
                            fontsize=max(ANNOT_SIZE - 1.5, 5.5),
                            color="#FFFFFF", fontweight="bold",
                            fontfamily=FONT_FAMILY, zorder=6)
                ang = end_a

    # ── Centre hole ────────────────────────────────────────────────────
    hole = plt.Circle((0, 0), r_inner_min - 0.02,
                       color=T["BG"], zorder=6)
    ax.add_patch(hole)

    # Centre KPI text
    ax.text(0,  0.10, _smart_fmt(total),
            ha="center", va="center",
            fontsize=11, fontweight="bold",
            color=T["TEXT"], fontfamily=FONT_FAMILY, zorder=7)
    ax.text(0, -0.13, "Total",
            ha="center", va="center",
            fontsize=ANNOT_SIZE, color=T["MUTED"],
            fontfamily=FONT_FAMILY, zorder=7)

    _draw_title(ax, cfg["title"], cfg.get("subtitle",""),
                accent_color=clrs_outer[0], dark=dark)

    if show_leg and ax_leg:
        _populate_legend(ax_leg, handles,
                         [h.get_label() for h in handles],
                         ncols=min(3, n_parents), dark=dark)

    return _to_b64(fig)


# ── Dispatcher ────────────────────────────────────────────────────────
_RENDERERS = {
    "line":      _line,
    "bar":       _bar,
    "pie":       _pie,
    "donut":     _donut,
    "area":      _area,
    "hbar":      _hbar,
    "scatter":   _scatter,
    "combo":     _combo,
    "waterfall": _waterfall,
    "sunburst":  _sunburst,
}

def render_chart(df: pd.DataFrame, cfg: dict) -> Optional[str]:
    fn = _RENDERERS.get(cfg["chart_type"])
    if fn is None:
        print(f"    [WARN] Unknown chart_type='{cfg['chart_type']}'.")
        return None
    if df.empty:
        print(f"    [WARN] Empty data for '{cfg['variable_name']}'.")
        return None
    return fn(df, cfg)


# ══════════════════════════════════════════════════════════════════════
# 7.  PLACEHOLDER SCANNER
# ══════════════════════════════════════════════════════════════════════

_RE = re.compile(r"\{\{([A-Z0-9_]+)\}\}")

def find_placeholders(html: str) -> list:
    seen, out = set(), []
    for m in _RE.finditer(html):
        n = m.group(1)
        if n not in seen:
            seen.add(n); out.append(n)
    return out


# ══════════════════════════════════════════════════════════════════════
# 8.  HTML HELPERS
# ══════════════════════════════════════════════════════════════════════

def _img_block(b64: str, cfg: dict) -> str:
    return (
        f'<div class="chart-wrap" style="margin:0 0 24px 0;border-radius:8px;'
        f'overflow:hidden;border:1px solid #E8ECF4;">'
        f'<!--[if mso]><table><tr><td><![endif]-->'
        f'<img src="{b64}" alt="{cfg["title"]}" width="{cfg["width_px"]}"'
        f' style="display:block;max-width:100%;height:auto;" />'
        f'<!--[if mso]></td></tr></table><![endif]-->'
        f'</div>'
    )

def _stat_banner(stats: list) -> str:
    """
    Premium KPI stat banner — responsive grid of metric cards.
    stats = [{"label": str, "value": str, "delta": str, "positive": bool}, ...]
    """
    if not stats:
        return ""
    cells = []
    for s in stats:
        pos = s.get("positive", True)
        delta_color = "#059669" if pos else "#E11D48"
        delta_bg    = "#ECFDF5" if pos else "#FFF1F2"
        arrow       = "▲" if pos else "▼"
        delta_html  = (
            f'<div style="margin-top:4px;">'
            f'<span style="display:inline-block;background:{delta_bg};'
            f'color:{delta_color};font-size:10px;font-weight:700;'
            f'padding:2px 7px;border-radius:20px;">'
            f'{arrow} {s.get("delta","")}</span></div>'
        ) if s.get("delta") else ""

        cells.append(
            f'<td style="padding:14px 16px;text-align:center;'
            f'background:#FFFFFF;border-radius:8px;'
            f'border:1px solid #E4E8F0;vertical-align:top;">'
            f'<p style="margin:0;font-size:10px;font-weight:700;color:#9AA3B8;'
            f'text-transform:uppercase;letter-spacing:0.08em;font-family:Arial;">'
            f'{s["label"]}</p>'
            f'<p style="margin:6px 0 0;font-size:22px;font-weight:800;color:#111827;'
            f'font-family:Arial;line-height:1;">{s["value"]}</p>'
            f'{delta_html}</td>'
        )

    spacer = "<td style='width:10px'></td>"
    cols = spacer.join(cells)
    return (
        f'<table width="100%" cellpadding="0" cellspacing="0" border="0">'
        f'<tr>{cols}</tr></table>'
    )

def _envelope(body: str, row: dict, stats: list = None) -> str:
    subject    = row.get("subject","Report")
    banner_html = _stat_banner(stats or [])
    ts         = datetime.now(timezone.utc).strftime("%B %d, %Y · %H:%M UTC")
    email_id   = row.get("email_id","")
    sender     = row.get("sender_email","")
    recipient  = row.get("recipient_email","")
    return f"""<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"
      xmlns:o="urn:schemas-microsoft-com:office:office">
<head>
  <meta charset="UTF-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width,initial-scale=1"/>
  <!--[if mso]>
  <xml><o:OfficeDocumentSettings>
    <o:AllowPNG/><o:PixelsPerInch>96</o:PixelsPerInch>
  </o:OfficeDocumentSettings></xml>
  <![endif]-->
  <title>{subject}</title>
  <style>
    body {{ margin:0; padding:0; background:#EEF1F6; font-family:Arial,Helvetica,sans-serif; }}
    .wrapper {{ max-width:700px; margin:0 auto; padding:32px 16px; }}
    .card {{ background:#FFFFFF; border-radius:12px; overflow:hidden;
              border:1px solid #D8DCE8; box-shadow:0 2px 12px rgba(0,0,0,0.06); }}
    .header {{ background:linear-gradient(135deg,#1A2B4A 0%,#243761 100%);
               padding:28px 32px 24px; }}
    .header-logo {{ font-size:11px; color:#60A5FA; font-weight:700;
                    letter-spacing:0.12em; text-transform:uppercase;
                    margin-bottom:10px; }}
    .header-title {{ font-size:20px; font-weight:800; color:#FFFFFF;
                     line-height:1.3; margin:0 0 8px; }}
    .header-meta {{ font-size:11px; color:#94A3B8; }}
    .divider {{ height:1px; background:#EEF1F6; margin:0; }}
    .body-pad {{ padding:28px 32px 32px; }}
    .section-label {{ font-size:10px; font-weight:700; color:#94A3B8;
                      letter-spacing:0.10em; text-transform:uppercase;
                      margin:24px 0 8px; padding-bottom:6px;
                      border-bottom:1px solid #EEF1F6; }}
    .section-label:first-child {{ margin-top:0; }}
    .chart-wrap {{ margin:0 0 20px; border-radius:8px; overflow:hidden;
                   border:1px solid #EEF1F6; }}
    .chart-wrap img {{ display:block; width:100%; height:auto; }}
    .footer {{ background:#F7F9FC; border-top:1px solid #E8ECF4;
               padding:16px 32px; }}
    .footer p {{ margin:0; font-size:11px; color:#9AA3B8; line-height:1.6; }}
    .badge {{ display:inline-block; background:#EEF1F6; border-radius:4px;
              padding:2px 8px; font-size:10px; color:#6B7894; font-weight:600; }}
  </style>
</head>
<body>
<div class="wrapper">
<table class="card" width="100%" cellpadding="0" cellspacing="0" border="0">

  <!-- ── Header ── -->
  <tr>
    <td class="header">
      <div class="header-logo">Analytics Report</div>
      <div class="header-title">{subject}</div>
      <div class="header-meta">
        Generated {ts} &nbsp;·&nbsp; <span class="badge" style="background:rgba(255,255,255,0.12);color:#94A3B8;">{email_id}</span>
      </div>
    </td>
  </tr>

  <!-- ── Stat banner ── -->
  {"<tr><td style='padding:20px 32px 4px; background:#F7F9FC; border-bottom:1px solid #EEF1F6;'>" + banner_html + "</td></tr>" if banner_html else ""}

  <!-- ── Body ── -->
  <tr>
    <td class="body-pad">
      {body}
    </td>
  </tr>

  <!-- ── Footer ── -->
  <tr>
    <td class="footer">
      <p>
        Sent to <strong style="color:#4B5563;">{recipient}</strong>
        &nbsp;·&nbsp; From <strong style="color:#4B5563;">{sender}</strong>
      </p>
      <p style="margin-top:4px;">
        Charts are embedded as base64 images — compatible with Outlook and all major email clients.
      </p>
    </td>
  </tr>

</table>
</div>
</body>
</html>"""


# ══════════════════════════════════════════════════════════════════════
# 9.  OUTPUT ROW BUILDER
# ══════════════════════════════════════════════════════════════════════

def build_output_row(email_row, final_html, charts_injected,
                     total_placeholders, error_message="") -> dict:
    if error_message:
        status = "FAILED"
    elif charts_injected == 0:
        status  = "FAILED"
        error_message = "No charts injected."
    elif charts_injected < total_placeholders:
        status  = "WARN"          # v7: finer-grained status (was PARTIAL)
        error_message = (f"{charts_injected}/{total_placeholders} injected. "
                         "Some placeholders had no config or returned empty data.")
    else:
        status = "SUCCESS"

    return {
        "email_id":        str(email_row.get("email_id","")),
        "sender_email":    str(email_row.get("sender_email","")),
        "recipient_email": str(email_row.get("recipient_email","")),
        "subject":         str(email_row.get("subject","")),
        "final_html":      final_html,
        "charts_injected": int(charts_injected),
        "status":          status,
        "error_message":   error_message,
        "processed_at":    datetime.now(timezone.utc).isoformat(),
    }


# ══════════════════════════════════════════════════════════════════════
# 10. MAIN PIPELINE  —  v7: parallel chart rendering
# ══════════════════════════════════════════════════════════════════════

def _render_one(var: str, config_map: dict, bq: BigQueryClient,
                runtime_vars: dict | None = None) -> tuple:
    """
    Worker function: resolve variables → fetch data → render one chart.
    Returns (var, b64_or_None, cfg, error_str).
    Designed to run in a thread pool.
    """
    if var not in config_map:
        return (var, None, None, f"'{var}' not in chart_config")

    raw_cfg = config_map[var]
    # ── Variable substitution ─────────────────────────────────────────
    try:
        cfg = resolve_cfg(raw_cfg, runtime_vars)
    except Exception as exc:
        return (var, None, raw_cfg, f"Variable resolution failed: {exc}")

    try:
        sql = build_select(cfg)
        df  = bq.query(sql)
        if df.empty:
            return (var, None, cfg, "0 rows returned")
        b64 = render_chart(df, cfg)
        return (var, b64, cfg, "")
    except Exception as exc:
        return (var, None, cfg, str(exc))


def process_emails(bq: BigQueryClient) -> list:
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # ── Build runtime variable context once for this run ───────────────
    runtime_vars = _build_runtime_vars()
    print("► Runtime variable context:")
    _preview_keys = ["project","env","today","yesterday","this_month",
                     "last_month","this_quarter_year","last_quarter_year"]
    for k in _preview_keys:
        print(f"    {{{k}}} → {runtime_vars.get(k,'')}")
    if TABLE_VARS:
        print("  User TABLE_VARS:")
        for k, v in TABLE_VARS.items():
            print(f"    {{{k}}} → {v}")
    print()

    print("► Loading chart_config...")
    cfg_df     = bq.query(f"SELECT * FROM `{resolve(CHART_CONFIG_TABLE, runtime_vars)}`")
    config_map = {}
    for _, r in cfg_df.iterrows():
        cfg = parse_config(r.to_dict())
        config_map[cfg["variable_name"]] = cfg
    print(f"  {len(config_map)} config(s): {list(config_map.keys())}")

    print("\n► Loading email_body...")
    emails_df = bq.query(f"SELECT * FROM `{resolve(EMAIL_BODY_VIEW, runtime_vars)}`")
    print(f"  {len(emails_df)} email(s).\n")

    output_rows = []

    for _, email_row in emails_df.iterrows():
        email_id  = email_row["email_id"]
        html_body = str(email_row["html_body"])
        error_msg = ""
        injected  = 0

        print(f"{'─'*62}")
        print(f"  email_id  : {email_id}")
        print(f"  subject   : {email_row.get('subject','')}")
        print(f"  to        : {email_row.get('recipient_email','')}")

        placeholders = find_placeholders(html_body)
        total        = len(placeholders)
        print(f"  Placeholders ({total}): {placeholders}")

        # ── Parallel rendering with shared runtime_vars ─────────────
        results = {}
        with ThreadPoolExecutor(max_workers=MAX_WORKERS) as pool:
            futures = {
                pool.submit(_render_one, var, config_map, bq, runtime_vars): var
                for var in placeholders
            }
            for future in as_completed(futures):
                var, b64, cfg, err = future.result()
                results[var] = (b64, cfg, err)

        # ── Inject in original placeholder order ────────────────────
        for var in placeholders:
            b64, cfg, err = results.get(var, (None, None, "future missing"))
            token = f"{{{{{var}}}}}"

            if err:
                print(f"  [SKIP] '{var}' — {err}")
                continue
            if b64 is None:
                print(f"  [SKIP] '{var}' — render returned None")
                continue

            html_body = html_body.replace(token, _img_block(b64, cfg))
            injected += 1
            # Show resolved table path so operator can verify substitutions
            resolved_table = cfg.get("bq_table","?") if cfg else "?"
            print(f"  ✓ '{var}'  [{cfg['chart_type']}]  table={resolved_table}  (b64: {len(b64):,} chars)")

        # ── Build KPI stats from mock data ──────────────────────────
        kpi_stats = [
            {"label": "Total Revenue",  "value": "$787K", "delta": "+12.4%", "positive": True},
            {"label": "vs Target",      "value": "94.2%",  "delta": "-5.8pp", "positive": False},
            {"label": "Top Region",     "value": "North",  "delta": "$31.2K", "positive": True},
            {"label": "Deals Closed",   "value": "40",     "delta": "+8 MoM", "positive": True},
        ]
        final_html = _envelope(html_body, email_row.to_dict(), stats=kpi_stats)

        out_path = os.path.join(OUTPUT_DIR, f"email_{email_id}.html")
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(final_html)
        print(f"\n  ✓ Saved → {out_path}")

        row = build_output_row(
            email_row.to_dict(), final_html,
            injected, total, error_msg,
        )
        output_rows.append(row)
        print(f"  ✓ Output row  "
              f"[status={row['status']}, charts={row['charts_injected']}/{total}]")

    if output_rows:
        print(f"\n{'─'*62}")
        print(f"► Writing {len(output_rows)} row(s) → {EMAIL_OUTPUT_TABLE}  ({WRITE_MODE})")
        bq.insert_rows(EMAIL_OUTPUT_TABLE, output_rows, write_mode=WRITE_MODE)

    return output_rows


# ══════════════════════════════════════════════════════════════════════
# ENTRY POINT
# ══════════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    print("=" * 62)
    print("  BigQuery Chart Engine  v10  —  Final · Production Ready")
    print("=" * 62)
    print(f"  Key file    : {SERVICE_ACCOUNT_KEY_FILE}")
    print(f"  Project     : {PROJECT_ID}")
    print(f"  Mode        : {'MOCK' if USE_MOCK else 'LIVE BigQuery'}")
    print(f"  Write mode  : {WRITE_MODE}")
    print(f"  Output table: {EMAIL_OUTPUT_TABLE}")
    print(f"  Chart types : line, bar, pie, donut, area, hbar,")
    print(f"                scatter, combo, waterfall, sunburst  ← NEW")
    print(f"  Reports     : R001 Sales · R002 Product · R003 Exec P&L")
    print(f"  Workers     : {MAX_WORKERS}")
    print(f"  Table vars  : {{project}}, {{env}}, {{today}}, {{yesterday}},")
    print(f"                {{this_month}}, {{last_month}}, {{this_year}},")
    print(f"                {{this_quarter_year}}, {{last_quarter_year}}")
    if TABLE_VARS:
        print(f"  Custom vars : {list(TABLE_VARS.keys())}")
    print()

    bq   = BigQueryClient()
    rows = process_emails(bq)

    print(f"\n{'='*62}")
    print(f"  Done — {len(rows)} email(s) processed.")
    for r in rows:
        icon = {"SUCCESS":"✓","WARN":"⚠","FAILED":"✗"}.get(r["status"],"?")
        print(f"  {icon} [{r['email_id']}]  status={r['status']}"
              f"  charts={r['charts_injected']}  to={r['recipient_email']}")
        if r["error_message"]:
            print(f"      {r['error_message']}")
    print(f"  Files → {os.path.abspath(OUTPUT_DIR)}/")
    print("=" * 62)
