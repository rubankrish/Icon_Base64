-- ╔══════════════════════════════════════════════════════════════════════╗
-- ║   BigQuery Chart Engine  v10  —  Database Setup & Seed Data        ║
-- ║                                                                      ║
-- ║  USAGE:                                                              ║
-- ║    1. Replace YOUR_PROJECT_ID and YOUR_DATASET with real values      ║
-- ║    2. Run this entire script in BigQuery Console (or bq CLI)         ║
-- ║    3. Set USE_MOCK = False in chart_email_engine_v10.py              ║
-- ║    4. Point PROJECT_ID / EMAIL_BODY_VIEW / CHART_CONFIG_TABLE        ║
-- ║       to YOUR_PROJECT_ID.YOUR_DATASET.* and run the engine           ║
-- ║                                                                      ║
-- ║  TABLES CREATED:                                                     ║
-- ║    email_body           — one row per report email template          ║
-- ║    chart_config         — one row per chart placeholder              ║
-- ║    email_output         — engine writes rendered HTML here           ║
-- ║    prod_reports.*       — source data tables for all 3 reports       ║
-- ║      monthly_sales      — R001 + R002: revenue / units / targets     ║
-- ║      monthly_pnl        — R003: revenue, costs, gross profit         ║
-- ║      region_revenue     — R001: revenue by region                    ║
-- ║      category_quarterly — R002: sales by category × quarter          ║
-- ║      market_share       — R002: top-level segment share              ║
-- ║      market_sunburst    — R002: segment + sub-segment revenue        ║
-- ║      deal_performance   — R001: deal size × revenue × segment        ║
-- ║      pnl_bridge         — R003: P&L waterfall deltas                 ║
-- ║      cost_sunburst      — R003: cost category + line item amount     ║
-- ║      expense_breakdown  — R003: rolled-up expense by type            ║
-- ║                                                                      ║
-- ║  3 REPORTS:                                                          ║
-- ║    R001 — Monthly Sales Performance  → sales-team@company.com        ║
-- ║    R002 — Product & Category Analytics → product-team@company.com   ║
-- ║    R003 — Executive P&L Summary      → leadership@company.com       ║
-- ╚══════════════════════════════════════════════════════════════════════╝

-- ══════════════════════════════════════════════════════════════════════
-- 0.  REPLACE THESE TWO TOKENS BEFORE RUNNING
-- ══════════════════════════════════════════════════════════════════════
--   YOUR_PROJECT_ID  →  e.g.  my-analytics-project
--   YOUR_DATASET     →  e.g.  chart_engine

-- ══════════════════════════════════════════════════════════════════════
-- 1.  CONTROL TABLES  (read by the engine)
-- ══════════════════════════════════════════════════════════════════════

-- ── 1a. email_body ────────────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.YOUR_DATASET.email_body`
(
  email_id        STRING   NOT NULL,
  sender_email    STRING   NOT NULL,
  recipient_email STRING   NOT NULL,
  subject         STRING   NOT NULL,
  html_body       STRING   NOT NULL   -- {{PLACEHOLDER}} tokens embedded here
)
OPTIONS (description = 'Email templates with {{CHART_VAR}} placeholders');

INSERT INTO `YOUR_PROJECT_ID.YOUR_DATASET.email_body`
  (email_id, sender_email, recipient_email, subject, html_body)
VALUES

-- ── R001: Monthly Sales Performance ──────────────────────────────────
('R001',
 'reports@company.com',
 'sales-team@company.com',
 'Monthly Sales Performance — {this_month}',
 CONCAT(
   '<p style="font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 20px;">Dear Sales Team,</p>',
   '<p style="font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 28px;">',
   'Here is your monthly sales performance summary with revenue trends, regional breakdown, and deal pipeline analysis.</p>',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Revenue Trend vs Target</div>',
   '{{R001_LINE_REVENUE}}',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Revenue by Region</div>',
   '{{R001_PIE_REGION}}',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Top Regions Ranked</div>',
   '{{R001_HBAR_REGION}}',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Deal Size vs Revenue</div>',
   '{{R001_SCATTER_DEALS}}',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Revenue &amp; Units Combo</div>',
   '{{R001_COMBO_UNITS}}',
   '<p style="font-family:Arial;font-size:13px;color:#6B7280;margin:28px 0 0;line-height:1.7;">',
   'Best regards,<br/><strong style="color:#111827;">Analytics Team</strong></p>'
)),

-- ── R002: Product & Category Analytics ────────────────────────────────
('R002',
 'reports@company.com',
 'product-team@company.com',
 'Product & Category Analytics — {this_quarter_year}',
 CONCAT(
   '<p style="font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 20px;">Dear Product Team,</p>',
   '<p style="font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 28px;">',
   'Here is the quarterly product and category performance breakdown including market share and segment analysis.</p>',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Quarterly Sales by Category</div>',
   '{{R002_BAR_CATEGORY}}',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Market Share — Sunburst</div>',
   '{{R002_SUNBURST_MARKET}}',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Market Share by Segment</div>',
   '{{R002_DONUT_MARKET}}',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Category Growth Area</div>',
   '{{R002_AREA_GROWTH}}',
   '<p style="font-family:Arial;font-size:13px;color:#6B7280;margin:28px 0 0;line-height:1.7;">',
   'Best regards,<br/><strong style="color:#111827;">Analytics Team</strong></p>'
)),

-- ── R003: Executive P&L Summary ───────────────────────────────────────
('R003',
 'reports@company.com',
 'leadership@company.com',
 'Executive P&L Summary — {last_quarter_year}',
 CONCAT(
   '<p style="font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 20px;">Dear Leadership Team,</p>',
   '<p style="font-family:Arial;font-size:14px;color:#374151;line-height:1.7;margin:0 0 28px;">',
   'Please find the executive P&amp;L summary for {last_quarter_year} including cost structure, revenue bridge, and expense breakdown.</p>',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">P&amp;L Bridge — {last_quarter_year}</div>',
   '{{R003_WATERFALL_PNL}}',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Cost Structure Sunburst</div>',
   '{{R003_SUNBURST_COST}}',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Revenue vs Costs — Monthly</div>',
   '{{R003_LINE_REVCOS}}',
   '<div style="font-size:10px;font-weight:700;color:#9AA3B8;letter-spacing:0.10em;text-transform:uppercase;',
   'padding-bottom:8px;margin-bottom:12px;border-bottom:1px solid #EEF1F6;font-family:Arial;">Expense Breakdown</div>',
   '{{R003_PIE_EXPENSE}}',
   '<p style="font-family:Arial;font-size:13px;color:#6B7280;margin:28px 0 0;line-height:1.7;">',
   'Best regards,<br/><strong style="color:#111827;">Analytics Team</strong></p>'
));


-- ── 1b. chart_config ──────────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.YOUR_DATASET.chart_config`
(
  variable_name   STRING   NOT NULL,  -- must match {{PLACEHOLDER}} in email_body
  chart_type      STRING   NOT NULL,  -- line|bar|pie|donut|area|hbar|scatter|combo|waterfall|sunburst
  bq_table        STRING   NOT NULL,  -- supports {project},{env},{this_year} etc.
  filters         STRING,             -- WHERE clause fragment; supports variables
  x_column        STRING   NOT NULL,
  y_columns       STRING   NOT NULL,  -- comma-separated; col2=size, col3=category for scatter/sunburst
  legend          STRING,             -- yes|no
  title           STRING,             -- supports {this_year},{this_month} etc.
  subtitle        STRING,
  color_theme     STRING,             -- blue|cool|warm|vibrant|teal|green|purple|slate|default
  show_values     STRING,             -- yes|no
  sort_order      STRING,             -- asc|desc|none
  width_px        INT64,
  height_px       INT64,
  ref_line_value  STRING,             -- numeric; draws a reference line on chart
  ref_line_label  STRING,
  x_label         STRING,
  y_label         STRING,
  dark_mode       STRING              -- yes|no
)
OPTIONS (description = 'One row per chart placeholder. Variable substitution applied at runtime.');

INSERT INTO `YOUR_PROJECT_ID.YOUR_DATASET.chart_config`
VALUES

-- ════════════════════════════════════════════════════════
-- R001 — Monthly Sales Performance
-- ════════════════════════════════════════════════════════
('R001_LINE_REVENUE',  'line',
 '{project}.prod_reports.monthly_sales',  'report_year={this_year}',
 'Month', 'Revenue,Target',  'yes',
 'Monthly Revenue vs Target', 'Jan–Dec {this_year}',
 'blue',  'no',  'none',  620, 310,
 '70000', 'Monthly Target',  '',  'Revenue (USD)',  'no'),

('R001_PIE_REGION',    'pie',
 '{project}.prod_reports.region_revenue', 'report_year={this_year}',
 'Region', 'Revenue',  'yes',
 'Revenue by Region', 'FY {this_year}',
 'vibrant', 'yes', 'desc', 520, 360,
 '', '', '', '', 'no'),

('R001_HBAR_REGION',   'hbar',
 '{project}.prod_reports.region_revenue', 'report_year={this_year}',
 'Region', 'Revenue',  'no',
 'Revenue Ranking by Region', 'Sorted high to low',
 'teal',  'yes', 'desc', 560, 290,
 '', '', 'Revenue (USD)', '', 'no'),

('R001_SCATTER_DEALS', 'scatter',
 '{project}.prod_reports.deal_performance', 'report_year={this_year}',
 'DealSize', 'Revenue,Count,Segment', 'yes',
 'Deal Size vs Revenue', 'Bubble = deal count · {this_quarter_year}',
 'purple', 'no', 'none', 560, 310,
 '', '', 'Deal Size (USD)', 'Revenue (USD)', 'no'),

('R001_COMBO_UNITS',   'combo',
 '{project}.prod_reports.monthly_sales',  'report_year={this_year}',
 'Month', 'Revenue,Units', 'yes',
 'Revenue vs Units Sold', 'Bars = Revenue  /  Line = Units',
 'blue',  'no',  'none',  620, 320,
 '', '', '', 'Revenue (USD)', 'no'),

-- ════════════════════════════════════════════════════════
-- R002 — Product & Category Analytics
-- ════════════════════════════════════════════════════════
('R002_BAR_CATEGORY',   'bar',
 '{project}.prod_reports.category_quarterly', 'fiscal_year={this_year}',
 'Category', 'Q1,Q2,Q3,Q4', 'yes',
 'Quarterly Sales by Category', 'FY {this_year} breakdown',
 'cool',  'yes', 'none', 620, 330,
 '', '', '', 'Sales (USD)', 'no'),

('R002_SUNBURST_MARKET','sunburst',
 '{project}.prod_reports.market_sunburst',   'report_year={this_year}',
 'Segment', 'Revenue,SubSegment', 'yes',
 'Revenue by Segment & Sub-Segment', 'Two-level breakdown · FY {this_year}',
 'vibrant', 'yes', 'desc', 560, 400,
 '', '', '', '', 'no'),

('R002_DONUT_MARKET',   'donut',
 '{project}.prod_reports.market_share',      'report_year={this_year}',
 'Segment', 'Share', 'yes',
 'Market Share by Segment', 'As of {this_month}',
 'warm',  'yes', 'desc', 500, 360,
 '', '', '', '', 'no'),

('R002_AREA_GROWTH',    'area',
 '{project}.prod_reports.monthly_sales',     'report_year={this_year}',
 'Month', 'Revenue,Target', 'yes',
 'Cumulative Growth — Revenue vs Target', 'YTD · {this_month}',
 'blue',  'no',  'none',  620, 310,
 '', '', '', 'USD', 'no'),

-- ════════════════════════════════════════════════════════
-- R003 — Executive P&L Summary
-- ════════════════════════════════════════════════════════
('R003_WATERFALL_PNL',  'waterfall',
 '{project}.prod_reports.pnl_bridge',        'period=''{last_quarter_year}''',
 'Item', 'Delta', 'no',
 'P&L Bridge — {last_quarter_year}', 'Starting from Opening Balance',
 'default', 'yes', 'none', 620, 330,
 '', '', '', 'USD', 'no'),

('R003_SUNBURST_COST',  'sunburst',
 '{project}.prod_reports.cost_sunburst',     'period=''{last_quarter_year}''',
 'CostCategory', 'Amount,CostItem', 'yes',
 'Cost Structure Breakdown', 'Inner = Category  ·  Outer = Line Item',
 'warm',  'yes', 'desc', 560, 400,
 '', '', '', '', 'no'),

('R003_LINE_REVCOS',    'line',
 '{project}.prod_reports.monthly_pnl',       'report_year={this_year}',
 'Month', 'Revenue,Costs,GrossProfit', 'yes',
 'Revenue vs Costs — Monthly', 'Gross profit = Revenue − Costs',
 'green', 'no',  'none',  620, 310,
 '', '', '', 'USD', 'no'),

('R003_PIE_EXPENSE',    'pie',
 '{project}.prod_reports.expense_breakdown', 'period=''{last_quarter_year}''',
 'ExpenseType', 'Amount', 'yes',
 'Expense Breakdown', '{last_quarter_year}',
 'slate', 'yes', 'desc', 520, 360,
 '', '', '', '', 'no');


-- ── 1c. email_output  (engine writes here) ────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.YOUR_DATASET.email_output`
(
  email_id        STRING,
  sender_email    STRING,
  recipient_email STRING,
  subject         STRING,
  final_html      STRING,
  charts_injected INT64,
  status          STRING,    -- SUCCESS | WARN | FAILED
  error_message   STRING,
  processed_at    TIMESTAMP
)
OPTIONS (description = 'Rendered email HTML output written by the chart engine');


-- ══════════════════════════════════════════════════════════════════════
-- 2.  SOURCE DATA TABLES  (prod_reports dataset)
-- ══════════════════════════════════════════════════════════════════════
--  NOTE: Create this dataset first if it doesn't exist:
--    bq mk --dataset YOUR_PROJECT_ID:prod_reports

-- ── 2a. monthly_sales ─────────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.prod_reports.monthly_sales`
(
  report_year INT64   NOT NULL,
  Month       STRING  NOT NULL,
  Revenue     INT64   NOT NULL,
  Target      INT64   NOT NULL,
  Units       INT64   NOT NULL
);

INSERT INTO `YOUR_PROJECT_ID.prod_reports.monthly_sales`
  (report_year, Month, Revenue, Target, Units)
VALUES
  (2026, 'Jan', 42000, 45000, 210),
  (2026, 'Feb', 47500, 48000, 238),
  (2026, 'Mar', 53200, 52000, 266),
  (2026, 'Apr', 49800, 55000, 249),
  (2026, 'May', 61000, 60000, 305),
  (2026, 'Jun', 67300, 65000, 337),
  (2026, 'Jul', 72100, 70000, 361),
  (2026, 'Aug', 68900, 72000, 345),
  (2026, 'Sep', 74500, 75000, 373),
  (2026, 'Oct', 81200, 80000, 406),
  (2026, 'Nov', 78600, 82000, 393),
  (2026, 'Dec', 91000, 88000, 455),
  -- previous year for YoY comparisons
  (2025, 'Jan', 36000, 38000, 182),
  (2025, 'Feb', 40200, 41000, 201),
  (2025, 'Mar', 44800, 44000, 224),
  (2025, 'Apr', 41500, 46000, 208),
  (2025, 'May', 52000, 52000, 260),
  (2025, 'Jun', 58100, 56000, 291),
  (2025, 'Jul', 61400, 60000, 307),
  (2025, 'Aug', 59200, 63000, 296),
  (2025, 'Sep', 64800, 66000, 324),
  (2025, 'Oct', 70300, 70000, 352),
  (2025, 'Nov', 67900, 72000, 340),
  (2025, 'Dec', 80100, 78000, 401);


-- ── 2b. monthly_pnl ───────────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.prod_reports.monthly_pnl`
(
  report_year  INT64  NOT NULL,
  Month        STRING NOT NULL,
  Revenue      INT64  NOT NULL,
  Costs        INT64  NOT NULL,
  GrossProfit  INT64  NOT NULL
);

INSERT INTO `YOUR_PROJECT_ID.prod_reports.monthly_pnl`
  (report_year, Month, Revenue, Costs, GrossProfit)
VALUES
  (2026, 'Jan', 42000, 31000, 11000),
  (2026, 'Feb', 47500, 34000, 13500),
  (2026, 'Mar', 53200, 38000, 15200),
  (2026, 'Apr', 49800, 37000, 12800),
  (2026, 'May', 61000, 43000, 18000),
  (2026, 'Jun', 67300, 48000, 19300),
  (2026, 'Jul', 72100, 51000, 21100),
  (2026, 'Aug', 68900, 49000, 19900),
  (2026, 'Sep', 74500, 53000, 21500),
  (2026, 'Oct', 81200, 57000, 24200),
  (2026, 'Nov', 78600, 55000, 23600),
  (2026, 'Dec', 91000, 63000, 28000);


-- ── 2c. region_revenue ────────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.prod_reports.region_revenue`
(
  report_year INT64  NOT NULL,
  Region      STRING NOT NULL,
  Revenue     INT64  NOT NULL
);

INSERT INTO `YOUR_PROJECT_ID.prod_reports.region_revenue`
  (report_year, Region, Revenue)
VALUES
  (2026, 'North',   31200),
  (2026, 'South',   24500),
  (2026, 'East',    18900),
  (2026, 'West',    27800),
  (2026, 'Central', 15600),
  (2025, 'North',   27000),
  (2025, 'South',   21200),
  (2025, 'East',    16400),
  (2025, 'West',    24100),
  (2025, 'Central', 13500);


-- ── 2d. category_quarterly ────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.prod_reports.category_quarterly`
(
  fiscal_year INT64  NOT NULL,
  Category    STRING NOT NULL,
  Q1          INT64  NOT NULL,
  Q2          INT64  NOT NULL,
  Q3          INT64  NOT NULL,
  Q4          INT64  NOT NULL
);

INSERT INTO `YOUR_PROJECT_ID.prod_reports.category_quarterly`
  (fiscal_year, Category, Q1, Q2, Q3, Q4)
VALUES
  (2026, 'Electronics', 12000, 14500, 13200, 18900),
  (2026, 'Clothing',     8500,  9200, 11000, 14500),
  (2026, 'Food',         6200,  7800,  8100,  9300),
  (2026, 'Books',        3400,  4100,  3800,  4600),
  (2026, 'Sports',       5100,  6300,  7200,  8800),
  (2025, 'Electronics', 10200, 12100, 11500, 16300),
  (2025, 'Clothing',     7200,  7800,  9400, 12800),
  (2025, 'Food',         5400,  6600,  7100,  8100),
  (2025, 'Books',        2900,  3500,  3200,  4000),
  (2025, 'Sports',       4300,  5500,  6400,  7700);


-- ── 2e. market_share ──────────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.prod_reports.market_share`
(
  report_year INT64   NOT NULL,
  Segment     STRING  NOT NULL,
  Share       FLOAT64 NOT NULL
);

INSERT INTO `YOUR_PROJECT_ID.prod_reports.market_share`
  (report_year, Segment, Share)
VALUES
  (2026, 'Enterprise',  38.5),
  (2026, 'SMB',         24.2),
  (2026, 'Startup',     15.8),
  (2026, 'Consumer',    12.1),
  (2026, 'Government',   9.4),
  (2025, 'Enterprise',  36.0),
  (2025, 'SMB',         25.5),
  (2025, 'Startup',     14.2),
  (2025, 'Consumer',    13.8),
  (2025, 'Government',  10.5);


-- ── 2f. market_sunburst ───────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.prod_reports.market_sunburst`
(
  report_year INT64  NOT NULL,
  Segment     STRING NOT NULL,   -- inner ring (parent)
  SubSegment  STRING NOT NULL,   -- outer ring (child)
  Revenue     INT64  NOT NULL
);

INSERT INTO `YOUR_PROJECT_ID.prod_reports.market_sunburst`
  (report_year, Segment, SubSegment, Revenue)
VALUES
  (2026, 'Enterprise', 'Large Corp',  18000),
  (2026, 'Enterprise', 'Mid Corp',     9500),
  (2026, 'Enterprise', 'Public Co',    6200),
  (2026, 'SMB',        'Retail SMB',  14000),
  (2026, 'SMB',        'B2B SMB',      9800),
  (2026, 'Startup',    'SaaS',         8200),
  (2026, 'Startup',    'Fintech',      7100),
  (2026, 'Consumer',   'Direct',       6500),
  (2026, 'Consumer',   'Reseller',     4100),
  (2026, 'Consumer',   'Online',       2800),
  (2026, 'Government', 'Federal',      5200),
  (2026, 'Government', 'State',        3800);


-- ── 2g. deal_performance ──────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.prod_reports.deal_performance`
(
  report_year INT64  NOT NULL,
  DealSize    INT64  NOT NULL,
  Revenue     INT64  NOT NULL,
  Count       INT64  NOT NULL,
  Segment     STRING NOT NULL
);

INSERT INTO `YOUR_PROJECT_ID.prod_reports.deal_performance`
  (report_year, DealSize, Revenue, Count, Segment)
VALUES
  (2026,  8200,  6100,  3, 'SMB'),
  (2026, 95400, 88200,  1, 'Enterprise'),
  (2026, 15600, 12400,  5, 'SMB'),
  (2026, 72300, 68100,  2, 'Enterprise'),
  (2026, 34500, 29800,  4, 'Startup'),
  (2026, 11200,  9600,  7, 'Consumer'),
  (2026, 58700, 54200,  2, 'Enterprise'),
  (2026, 22100, 18900,  6, 'SMB'),
  (2026, 47800, 43500,  3, 'Startup'),
  (2026,  6500,  4800,  9, 'Consumer'),
  (2026, 83100, 79400,  1, 'Enterprise'),
  (2026, 19400, 16200,  5, 'SMB'),
  (2026, 38900, 34100,  4, 'Startup'),
  (2026, 12700, 10300,  8, 'Consumer'),
  (2026, 67200, 62800,  2, 'Enterprise'),
  (2026, 28600, 24400,  5, 'SMB'),
  (2026, 52400, 48700,  3, 'Startup'),
  (2026,  9800,  7900, 11, 'Consumer'),
  (2026, 91500, 87300,  1, 'Enterprise'),
  (2026, 25300, 21600,  6, 'SMB'),
  (2026, 43700, 39800,  3, 'Startup'),
  (2026, 16800, 14100,  7, 'Consumer'),
  (2026, 76400, 71900,  2, 'Enterprise'),
  (2026, 31200, 27100,  5, 'SMB'),
  (2026, 55900, 51200,  3, 'Startup'),
  (2026, 13400, 11200,  8, 'Consumer'),
  (2026, 88700, 84500,  1, 'Enterprise'),
  (2026, 18900, 15800,  6, 'SMB'),
  (2026, 41300, 37600,  4, 'Startup'),
  (2026,  7600,  5700, 12, 'Consumer'),
  (2026, 63800, 59700,  2, 'Enterprise'),
  (2026, 26700, 22900,  5, 'SMB'),
  (2026, 48200, 44600,  3, 'Startup'),
  (2026, 14100, 11900,  9, 'Consumer'),
  (2026, 79800, 75400,  2, 'Enterprise'),
  (2026, 33600, 29300,  4, 'SMB'),
  (2026, 57100, 53400,  3, 'Startup'),
  (2026, 10600,  8800, 10, 'Consumer'),
  (2026, 85200, 81100,  1, 'Enterprise'),
  (2026, 20800, 17700,  6, 'SMB');


-- ── 2h. pnl_bridge ────────────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.prod_reports.pnl_bridge`
(
  period  STRING NOT NULL,   -- e.g. 'Q1-2026'
  Item    STRING NOT NULL,
  Delta   INT64  NOT NULL
);

INSERT INTO `YOUR_PROJECT_ID.prod_reports.pnl_bridge`
  (period, Item, Delta)
VALUES
  ('Q1-2026', 'Opening',   120000),
  ('Q1-2026', 'New Sales',  52000),
  ('Q1-2026', 'Upsell',     21000),
  ('Q1-2026', 'Churn',     -18500),
  ('Q1-2026', 'Refunds',    -7200),
  ('Q1-2026', 'OpEx',      -38000),
  ('Q1-2026', 'Closing',        0),  -- 0 triggers auto-compute of running total
  ('Q4-2025', 'Opening',   105000),
  ('Q4-2025', 'New Sales',  44000),
  ('Q4-2025', 'Upsell',     17500),
  ('Q4-2025', 'Churn',     -15200),
  ('Q4-2025', 'Refunds',    -6100),
  ('Q4-2025', 'OpEx',      -34000),
  ('Q4-2025', 'Closing',        0);


-- ── 2i. cost_sunburst ─────────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.prod_reports.cost_sunburst`
(
  period       STRING NOT NULL,
  CostCategory STRING NOT NULL,   -- inner ring
  CostItem     STRING NOT NULL,   -- outer ring
  Amount       INT64  NOT NULL
);

INSERT INTO `YOUR_PROJECT_ID.prod_reports.cost_sunburst`
  (period, CostCategory, CostItem, Amount)
VALUES
  ('Q1-2026', 'Personnel',    'Salaries',     28000),
  ('Q1-2026', 'Personnel',    'Benefits',      6500),
  ('Q1-2026', 'Personnel',    'Contractors',   4200),
  ('Q1-2026', 'Infrastructure','Cloud',         8800),
  ('Q1-2026', 'Infrastructure','Office',        3200),
  ('Q1-2026', 'Sales & Mktg', 'Advertising',   7400),
  ('Q1-2026', 'Sales & Mktg', 'Events',        3100),
  ('Q1-2026', 'Sales & Mktg', 'Commissions',   5600),
  ('Q1-2026', 'R&D',          'Engineering',   9200),
  ('Q1-2026', 'R&D',          'Research',      4100),
  ('Q1-2026', 'G&A',          'Legal',         2800),
  ('Q1-2026', 'G&A',          'Finance',       1900),
  ('Q4-2025', 'Personnel',    'Salaries',     25500),
  ('Q4-2025', 'Personnel',    'Benefits',      5900),
  ('Q4-2025', 'Personnel',    'Contractors',   3800),
  ('Q4-2025', 'Infrastructure','Cloud',         7900),
  ('Q4-2025', 'Infrastructure','Office',        3200),
  ('Q4-2025', 'Sales & Mktg', 'Advertising',   6800),
  ('Q4-2025', 'Sales & Mktg', 'Events',        2600),
  ('Q4-2025', 'Sales & Mktg', 'Commissions',   5100),
  ('Q4-2025', 'R&D',          'Engineering',   8500),
  ('Q4-2025', 'R&D',          'Research',      3700),
  ('Q4-2025', 'G&A',          'Legal',         2500),
  ('Q4-2025', 'G&A',          'Finance',       1700);


-- ── 2j. expense_breakdown ─────────────────────────────────────────────
CREATE OR REPLACE TABLE `YOUR_PROJECT_ID.prod_reports.expense_breakdown`
(
  period      STRING  NOT NULL,
  ExpenseType STRING  NOT NULL,
  Amount      INT64   NOT NULL
);

INSERT INTO `YOUR_PROJECT_ID.prod_reports.expense_breakdown`
  (period, ExpenseType, Amount)
VALUES
  ('Q1-2026', 'Personnel',       38700),
  ('Q1-2026', 'Infrastructure',  12000),
  ('Q1-2026', 'Sales & Mktg',    16100),
  ('Q1-2026', 'R&D',             13300),
  ('Q1-2026', 'G&A',              4700),
  ('Q4-2025', 'Personnel',       35200),
  ('Q4-2025', 'Infrastructure',  11100),
  ('Q4-2025', 'Sales & Mktg',    14500),
  ('Q4-2025', 'R&D',             12200),
  ('Q4-2025', 'G&A',              4200);


-- ══════════════════════════════════════════════════════════════════════
-- 3.  VERIFICATION QUERIES  (run after insert to confirm row counts)
-- ══════════════════════════════════════════════════════════════════════

SELECT 'email_body'           AS tbl, COUNT(*) AS rows FROM `YOUR_PROJECT_ID.YOUR_DATASET.email_body`
UNION ALL
SELECT 'chart_config',               COUNT(*)          FROM `YOUR_PROJECT_ID.YOUR_DATASET.chart_config`
UNION ALL
SELECT 'monthly_sales',              COUNT(*)          FROM `YOUR_PROJECT_ID.prod_reports.monthly_sales`
UNION ALL
SELECT 'monthly_pnl',                COUNT(*)          FROM `YOUR_PROJECT_ID.prod_reports.monthly_pnl`
UNION ALL
SELECT 'region_revenue',             COUNT(*)          FROM `YOUR_PROJECT_ID.prod_reports.region_revenue`
UNION ALL
SELECT 'category_quarterly',         COUNT(*)          FROM `YOUR_PROJECT_ID.prod_reports.category_quarterly`
UNION ALL
SELECT 'market_share',               COUNT(*)          FROM `YOUR_PROJECT_ID.prod_reports.market_share`
UNION ALL
SELECT 'market_sunburst',            COUNT(*)          FROM `YOUR_PROJECT_ID.prod_reports.market_sunburst`
UNION ALL
SELECT 'deal_performance',           COUNT(*)          FROM `YOUR_PROJECT_ID.prod_reports.deal_performance`
UNION ALL
SELECT 'pnl_bridge',                 COUNT(*)          FROM `YOUR_PROJECT_ID.prod_reports.pnl_bridge`
UNION ALL
SELECT 'cost_sunburst',              COUNT(*)          FROM `YOUR_PROJECT_ID.prod_reports.cost_sunburst`
UNION ALL
SELECT 'expense_breakdown',          COUNT(*)          FROM `YOUR_PROJECT_ID.prod_reports.expense_breakdown`
ORDER BY tbl;

-- Expected row counts:
--   email_body            3
--   chart_config         13
--   monthly_sales        24  (12 months × 2 years)
--   monthly_pnl          12
--   region_revenue       10  (5 regions × 2 years)
--   category_quarterly   10  (5 categories × 2 years)
--   market_share         10  (5 segments × 2 years)
--   market_sunburst      12
--   deal_performance     40
--   pnl_bridge           14  (7 items × 2 quarters)
--   cost_sunburst        24  (12 items × 2 quarters)
--   expense_breakdown    10  (5 types × 2 quarters)
